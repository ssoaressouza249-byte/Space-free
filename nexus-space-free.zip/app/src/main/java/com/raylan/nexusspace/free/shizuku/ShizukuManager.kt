package com.raylan.nexusspace.free.shizuku

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.raylan.nexusspace.free.data.AnimationSpeed
import com.raylan.nexusspace.free.data.GameModeOption
import com.raylan.nexusspace.free.data.ShizukuStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.math.roundToInt

object ShizukuManager {
    private const val REQUEST_CODE_SHIZUKU = 2000
    private var initialized = false

    private val _status = MutableStateFlow(ShizukuStatus())
    val status: StateFlow<ShizukuStatus> = _status.asStateFlow()

    private val _lastFeedback = MutableStateFlow("Shizuku: aguardando inicialização...")
    val lastFeedback: StateFlow<String> = _lastFeedback.asStateFlow()

    private val _commandHistory = MutableStateFlow<List<String>>(emptyList())
    val commandHistory: StateFlow<List<String>> = _commandHistory.asStateFlow()

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshStatus()
        _lastFeedback.value = if (_status.value.isPermissionGranted) {
            "Shizuku conectado (Shell UID ${_status.value.uid}). Pronto para otimização."
        } else {
            "Shizuku detectado! Toque para autorizar permissão Shell."
        }
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        _status.value = ShizukuStatus(isBinderAlive = false, isPermissionGranted = false)
        _lastFeedback.value = "Conexão Shizuku encerrada. Reabra o Shizuku."
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == REQUEST_CODE_SHIZUKU) {
                val granted = grantResult == PackageManager.PERMISSION_GRANTED
                refreshStatus()
                _lastFeedback.value = if (granted) {
                    "Permissão Shizuku concedida (Shell UID 2000)."
                } else {
                    "Permissão Shizuku negada pelo usuário."
                }
            }
        }

    fun init() {
        if (initialized) {
            refreshStatus()
            return
        }
        initialized = true
        runCatching {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
            refreshStatus()
        }.onFailure { err ->
            _lastFeedback.value = "Shizuku indisponível no dispositivo (${err.message ?: "sem serviço"})."
        }
    }

    fun refreshStatus() {
        runCatching {
            val alive = Shizuku.pingBinder()
            val granted = if (alive) {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            } else {
                false
            }
            val uid = if (alive) runCatching { Shizuku.getUid() }.getOrDefault(-1) else -1
            val version = if (alive) runCatching { Shizuku.getVersion() }.getOrDefault(-1) else -1
            _status.value = ShizukuStatus(
                isBinderAlive = alive,
                isPermissionGranted = granted,
                uid = uid,
                version = version
            )
            if (alive && granted && _lastFeedback.value.contains("aguardando")) {
                _lastFeedback.value = "Shizuku conectado (UID $uid • v$version)."
            } else if (!alive) {
                _lastFeedback.value = "Shizuku inativo. Inicie o serviço Shizuku para comandos Shell."
            }
        }.onFailure {
            _status.value = ShizukuStatus(isBinderAlive = false, isPermissionGranted = false)
        }
    }

    fun requestPermission() {
        refreshStatus()
        runCatching {
            if (!Shizuku.pingBinder()) {
                _lastFeedback.value = "Serviço Shizuku não está ativo no sistema."
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                refreshStatus()
                _lastFeedback.value = "Shizuku já autorizado (UID ${_status.value.uid})."
                return
            }
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                _lastFeedback.value = "Conceda permissão ao NEXUS SPACE FREE dentro do app Shizuku."
            }
            Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
        }.onFailure { err ->
            _lastFeedback.value = "Erro ao solicitar Shizuku: ${err.message ?: "falha"}"
        }
    }

    fun openShizukuApp(context: Context) {
        runCatching {
            val launch = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
            } else {
                _lastFeedback.value = "App Shizuku (moe.shizuku.privileged.api) não instalado."
            }
        }
    }

    suspend fun runCommand(cmd: String): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        refreshStatus()
        val current = _status.value
        if (!current.isBinderAlive) {
            val msg = "Shizuku offline: ative o Shizuku para executar '$cmd'"
            _lastFeedback.value = msg
            appendHistory("ERR $ $cmd -> offline")
            return@withContext Pair(false, msg)
        }
        if (!current.isPermissionGranted) {
            val msg = "Permissão Shizuku pendente: autorize o acesso Shell."
            _lastFeedback.value = msg
            appendHistory("ERR $ $cmd -> sem permissão")
            return@withContext Pair(false, msg)
        }

        val execution = runCatching {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            ).apply { isAccessible = true }

            val process = method.invoke(
                null,
                arrayOf("sh", "-c", cmd),
                null,
                null
            ) as Process

            val stdout = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }.trim()
            val stderr = BufferedReader(InputStreamReader(process.errorStream)).use { it.readText() }.trim()
            val exitCode = process.waitFor()

            val combined = buildString {
                if (stdout.isNotEmpty()) append(stdout)
                if (stderr.isNotEmpty()) {
                    if (isNotEmpty()) append("\n")
                    append(stderr)
                }
                if (isEmpty()) append("OK (código $exitCode)")
            }

            val success = exitCode == 0
            val summary = if (success) "Executado: ${combined.lineSequence().firstOrNull() ?: "OK"}" else "Falha ($exitCode): ${combined.lineSequence().firstOrNull() ?: "erro"}"
            _lastFeedback.value = summary
            appendHistory("${if (success) "OK" else "ERR($exitCode)"} $ $cmd")
            Pair(success, combined)
        }

        execution.getOrElse { err ->
            val msg = "Erro Shizuku: ${err.message ?: "falha na invocação"}"
            _lastFeedback.value = msg
            appendHistory("EX $ $cmd -> ${err.message}")
            Pair(false, msg)
        }
    }

    private fun appendHistory(entry: String) {
        val updated = (_commandHistory.value + entry).takeLast(12)
        _commandHistory.value = updated
    }

    // --- 14 FREE FUNCTIONS ---

    suspend fun cleanRamAndCache(context: Context): Pair<Boolean, String> {
        runCatching {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            am.runningAppProcesses?.forEach { proc ->
                if (proc.pkgList != null) {
                    proc.pkgList.forEach { pkg ->
                        if (pkg != context.packageName) {
                            runCatching { am.killBackgroundProcesses(pkg) }
                        }
                    }
                }
            }
        }
        return runCommand("pm trim-caches 999G && am kill-all")
    }

    suspend fun compileGameFast(packageName: String): Pair<Boolean, String> {
        return runCommand("cmd package compile -m speed-profile -f $packageName")
    }

    suspend fun blockBackgroundApps(): Pair<Boolean, String> {
        return runCommand("cmd appops set --all RUN_IN_BACKGROUND ignore")
    }

    suspend fun setAnimationsScale(speed: AnimationSpeed): Pair<Boolean, String> {
        val s = speed.scale
        return runCommand("settings put global window_animation_scale $s && settings put global transition_animation_scale $s && settings put global animator_duration_scale $s")
    }

    suspend fun optimizeStandbyBucket(packageName: String): Pair<Boolean, String> {
        return runCommand("am set-standby-bucket $packageName active")
    }

    suspend fun clearSystemLogs(): Pair<Boolean, String> {
        return runCommand("logcat -c")
    }

    suspend fun clearDnsCache(): Pair<Boolean, String> {
        return runCommand("ndc resolver clearnetdns")
    }

    suspend fun setRefreshRate(hz: Int): Pair<Boolean, String> {
        val safeHz = if (hz >= 90) 90 else 60
        return runCommand("settings put system peak_refresh_rate ${safeHz}.0 && settings put system min_refresh_rate ${safeHz}.0")
    }

    suspend fun setSensiMultiplier(multiplier: Float): Pair<Boolean, String> {
        // Maps 0.50x..1.40x to Android pointer_speed (-3..7)
        val clamped = multiplier.coerceIn(0.50f, 1.40f)
        val pointerSpeed = (((clamped - 0.50f) / 0.90f) * 10f - 3f).roundToInt().coerceIn(-3, 7)
        return runCommand("settings put system pointer_speed $pointerSpeed")
    }

    suspend fun enableQuickTouch(): Pair<Boolean, String> {
        return runCommand("settings put system pointer_speed 5")
    }

    suspend fun setGameMode(packageName: String, mode: GameModeOption): Pair<Boolean, String> {
        val modeArg = when (mode) {
            GameModeOption.STANDARD -> "standard"
            GameModeOption.BALANCED -> "1"
        }
        return runCommand("cmd game mode $modeArg $packageName")
    }

    suspend fun resetPhoneDisplay(): Pair<Boolean, String> {
        return runCommand("wm size reset && wm density reset")
    }

    suspend fun applyTurboFree(context: Context, gamePackage: String): Pair<Boolean, String> {
        cleanRamAndCache(context)
        optimizeStandbyBucket(gamePackage)
        compileGameFast(gamePackage)
        clearSystemLogs()
        val dns = clearDnsCache()
        _lastFeedback.value = "Turbo Grátis aplicado para $gamePackage!"
        return dns
    }
}
