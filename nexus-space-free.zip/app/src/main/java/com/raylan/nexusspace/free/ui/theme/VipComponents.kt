package com.raylan.nexusspace.free.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

private val vipFeaturesList = listOf(
    "Taxa de Atualização 120 Hz & 144 Hz Real",
    "Gráfico Liso OpenGL & Downscale 50% a 85%",
    "Limite de FPS 120 e Máx (cmd game + swapinterval 0)",
    "Resolução Livre Customizada (wm size pro)",
    "Compilação Zero-Logo, Sensi Pro 1.45x–2.00x & Toque 0ms",
    "Modo Gelo (Resfriamento Profundo + Thermal Override)",
    "3 Papéis de Parede VIP + Importar da Galeria"
)

@Composable
fun VipBannerButton(
    text: String = "★ OBTER NEXUS SPACE VIP",
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(Color(0xFFFFD700), Color(0xFFFFA000))
                )
            )
            .border(1.dp, Color(0xFFFFF3B0), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(
                horizontal = if (compact) 10.dp else 12.dp,
                vertical = if (compact) 6.dp else 7.dp
            )
            .testTag("vip_banner_button"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        VipCrownGlyph(size = if (compact) 14.dp else 16.dp, tint = Color(0xFF1F1600))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = text,
            color = Color(0xFF1A1200),
            fontWeight = FontWeight.ExtraBold,
            fontSize = if (compact) 10.sp else 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun VipUpgradeDialog(
    featureContext: String?,
    onDismiss: () -> Unit,
    onOpenDiscord: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 540.dp)
                .padding(16.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF141824), Color(0xFF0A0D16))
                    )
                )
                .border(1.5.dp, NexusGold.copy(alpha = 0.85f), RoundedCornerShape(20.dp))
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(NexusGold.copy(alpha = 0.18f)),
                            contentAlignment = Alignment.Center
                        ) {
                            VipCrownGlyph(size = 22.dp, tint = NexusGold)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "NEXUS SPACE VIP",
                                color = NexusGold,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = featureContext?.let { "Recurso VIP: $it" } ?: "Desbloqueie o poder máximo",
                                color = NexusTextSecondary,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Fechar diálogo VIP",
                            tint = NexusTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0E1320))
                        .border(1.dp, NexusGold.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    vipFeaturesList.forEach { item ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = NexusGold,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = item,
                                color = NexusTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.height(48.dp)
                    ) {
                        Text(
                            text = "Continuar Grátis",
                            color = NexusTextSecondary,
                            fontSize = 13.sp
                        )
                    }
                    Button(
                        onClick = onOpenDiscord,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NexusGold,
                            contentColor = Color(0xFF1A1200)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("buy_vip_discord_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "COMPRAR VIP NO DISCORD",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun VipHudLockCard(
    featureTitle: String,
    onDismiss: () -> Unit,
    onOpenDiscord: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xF5151926))
            .border(1.5.dp, NexusGold, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                VipCrownGlyph(size = 16.dp, tint = NexusGold)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Liberar Versão VIP no Discord",
                    color = NexusGold,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp
                )
            }
            IconButton(
                onClick = onDismiss,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Fechar cartão VIP",
                    tint = NexusTextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
        Text(
            text = "O recurso \"$featureTitle\" é exclusivo do NEXUS SPACE VIP (120/144Hz, Gráfico Liso, Resolução Livre e Modo Gelo).",
            color = NexusTextPrimary,
            fontSize = 11.sp
        )
        Button(
            onClick = onOpenDiscord,
            colors = ButtonDefaults.buttonColors(
                containerColor = NexusGold,
                contentColor = Color(0xFF1A1200)
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
        ) {
            Text(
                text = "COMPRAR VIP NO DISCORD",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 12.sp
            )
        }
    }
}
