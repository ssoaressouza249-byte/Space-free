package com.raylan.nexusspace.free.ui.theme

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.raylan.nexusspace.free.data.CrosshairStyle
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun NexusLogoGlyph(
    modifier: Modifier = Modifier,
    size: Dp = 24.dp,
    tint: Color = NexusCyan
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val stroke = w * 0.11f

        val hex = Path().apply {
            moveTo(w * 0.5f, h * 0.06f)
            lineTo(w * 0.90f, h * 0.28f)
            lineTo(w * 0.90f, h * 0.72f)
            lineTo(w * 0.5f, h * 0.94f)
            lineTo(w * 0.10f, h * 0.72f)
            lineTo(w * 0.10f, h * 0.28f)
            close()
        }
        drawPath(hex, color = tint.copy(alpha = 0.22f))
        drawPath(hex, color = tint, style = Stroke(width = stroke * 0.65f))

        // Stylized 'N'
        val nPath = Path().apply {
            moveTo(w * 0.30f, h * 0.72f)
            lineTo(w * 0.30f, h * 0.28f)
            lineTo(w * 0.70f, h * 0.72f)
            lineTo(w * 0.70f, h * 0.28f)
        }
        drawPath(
            path = nPath,
            color = Color.White,
            style = Stroke(width = stroke, cap = StrokeCap.Round)
        )
    }
}

@Composable
fun VipCrownGlyph(
    modifier: Modifier = Modifier,
    size: Dp = 18.dp,
    tint: Color = NexusGold
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val path = Path().apply {
            moveTo(w * 0.12f, h * 0.78f)
            lineTo(w * 0.10f, h * 0.30f)
            lineTo(w * 0.34f, h * 0.52f)
            lineTo(w * 0.50f, h * 0.18f)
            lineTo(w * 0.66f, h * 0.52f)
            lineTo(w * 0.90f, h * 0.30f)
            lineTo(w * 0.88f, h * 0.78f)
            close()
        }
        drawPath(path, color = tint)
        drawRoundRect(
            color = tint,
            topLeft = Offset(w * 0.14f, h * 0.82f),
            size = Size(w * 0.72f, h * 0.10f),
            cornerRadius = CornerRadius(4f, 4f)
        )
    }
}

@Composable
fun TurboLightningGlyph(
    modifier: Modifier = Modifier,
    size: Dp = 22.dp,
    tint: Color = NexusEmerald
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val bolt = Path().apply {
            moveTo(w * 0.56f, h * 0.08f)
            lineTo(w * 0.22f, h * 0.54f)
            lineTo(w * 0.48f, h * 0.54f)
            lineTo(w * 0.40f, h * 0.92f)
            lineTo(w * 0.78f, h * 0.44f)
            lineTo(w * 0.52f, h * 0.44f)
            close()
        }
        drawPath(bolt, color = tint)
    }
}

@Composable
fun IceCrystalGlyph(
    modifier: Modifier = Modifier,
    size: Dp = 22.dp,
    tint: Color = Color(0xFF7CE8FF)
) {
    Canvas(modifier = modifier.size(size)) {
        val cx = this.size.width / 2f
        val cy = this.size.height / 2f
        val r = this.size.minDimension * 0.42f
        val stroke = this.size.minDimension * 0.09f
        for (i in 0 until 3) {
            val angle = Math.toRadians((i * 60).toDouble())
            val dx = (cos(angle) * r).toFloat()
            val dy = (sin(angle) * r).toFloat()
            drawLine(
                color = tint,
                start = Offset(cx - dx, cy - dy),
                end = Offset(cx + dx, cy + dy),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )
        }
        drawCircle(color = Color.White, radius = stroke * 0.85f, center = Offset(cx, cy))
    }
}

@Composable
fun GamepadGlyph(
    modifier: Modifier = Modifier,
    size: Dp = 22.dp,
    tint: Color = NexusCyan
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        drawRoundRect(
            color = tint.copy(alpha = 0.22f),
            topLeft = Offset(w * 0.10f, h * 0.26f),
            size = Size(w * 0.80f, h * 0.48f),
            cornerRadius = CornerRadius(w * 0.22f, w * 0.22f)
        )
        drawRoundRect(
            color = tint,
            topLeft = Offset(w * 0.10f, h * 0.26f),
            size = Size(w * 0.80f, h * 0.48f),
            cornerRadius = CornerRadius(w * 0.22f, w * 0.22f),
            style = Stroke(width = w * 0.08f)
        )
        // D-pad left
        drawLine(tint, Offset(w * 0.24f, h * 0.50f), Offset(w * 0.40f, h * 0.50f), strokeWidth = w * 0.08f, cap = StrokeCap.Round)
        drawLine(tint, Offset(w * 0.32f, h * 0.42f), Offset(w * 0.32f, h * 0.58f), strokeWidth = w * 0.08f, cap = StrokeCap.Round)
        // Buttons right
        drawCircle(NexusGold, radius = w * 0.055f, center = Offset(w * 0.68f, h * 0.43f))
        drawCircle(NexusEmerald, radius = w * 0.055f, center = Offset(w * 0.74f, h * 0.55f))
    }
}

@Composable
fun CrosshairCanvas(
    style: CrosshairStyle,
    modifier: Modifier = Modifier,
    size: Dp = 36.dp,
    color: Color = NexusCyan
) {
    Canvas(modifier = modifier.size(size)) {
        val cx = this.size.width / 2f
        val cy = this.size.height / 2f
        val dim = this.size.minDimension
        when (style) {
            CrosshairStyle.NONE -> Unit
            CrosshairStyle.DOT -> {
                drawCircle(color = Color.Black.copy(alpha = 0.65f), radius = dim * 0.16f, center = Offset(cx, cy))
                drawCircle(color = color, radius = dim * 0.11f, center = Offset(cx, cy))
            }
            CrosshairStyle.CROSS -> {
                val gap = dim * 0.14f
                val arm = dim * 0.42f
                val stroke = dim * 0.08f
                drawLine(color, Offset(cx - arm, cy), Offset(cx - gap, cy), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx + gap, cy), Offset(cx + arm, cy), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx, cy - arm), Offset(cx, cy - gap), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx, cy + gap), Offset(cx, cy + arm), strokeWidth = stroke, cap = StrokeCap.Round)
                drawCircle(color = NexusGold, radius = stroke * 0.65f, center = Offset(cx, cy))
            }
            CrosshairStyle.CIRCLE -> {
                val r = dim * 0.34f
                val stroke = dim * 0.075f
                drawCircle(color = color, radius = r, center = Offset(cx, cy), style = Stroke(width = stroke))
                drawCircle(color = NexusGold, radius = dim * 0.08f, center = Offset(cx, cy))
            }
        }
    }
}

@Composable
fun FpsSpeedometerGauge(
    fps: Int,
    targetMaxFps: Int = 90,
    modifier: Modifier = Modifier,
    size: Dp = 76.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val stroke = this.size.minDimension * 0.11f
        val pad = stroke / 2f
        val arcSize = Size(this.size.width - stroke, this.size.height - stroke)
        val topLeft = Offset(pad, pad)

        // Track
        drawArc(
            color = Color(0xFF1F2A44),
            startAngle = 135f,
            sweepAngle = 270f,
            useCenter = false,
            topLeft = topLeft,
            size = arcSize,
            style = Stroke(width = stroke, cap = StrokeCap.Round)
        )

        val progress = (fps.toFloat() / targetMaxFps.coerceAtLeast(60)).coerceIn(0.05f, 1f)
        val arcColor = when {
            fps >= 55 -> NexusEmerald
            fps >= 40 -> NexusCyan
            else -> NexusAmber
        }
        drawArc(
            color = arcColor,
            startAngle = 135f,
            sweepAngle = 270f * progress,
            useCenter = false,
            topLeft = topLeft,
            size = arcSize,
            style = Stroke(width = stroke, cap = StrokeCap.Round)
        )
    }
}
