package com.raylan.nexusspace.free

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.raylan.nexusspace.free.data.CrosshairStyle
import com.raylan.nexusspace.free.data.DesktopSection
import com.raylan.nexusspace.free.data.NexusRepository
import com.raylan.nexusspace.free.security.SecurityGuard
import com.raylan.nexusspace.free.security.TamperLockScreen
import com.raylan.nexusspace.free.shizuku.ShizukuManager
import com.raylan.nexusspace.free.telemetry.TelemetryMonitor
import com.raylan.nexusspace.free.ui.desktop.VirtualPcDesktopScreen
import com.raylan.nexusspace.free.ui.desktop.WallpaperWindow
import com.raylan.nexusspace.free.ui.gamespace.ControlCenterScreen
import com.raylan.nexusspace.free.ui.overlay.HudOverlayService
import com.raylan.nexusspace.free.ui.theme.CrosshairCanvas
import com.raylan.nexusspace.free.ui.theme.NexusCyan
import com.raylan.nexusspace.free.ui.theme.NexusSpaceTheme
import com.raylan.nexusspace.free.ui.theme.NexusTextPrimary
import com.raylan.nexusspace.free.ui.theme.VipUpgradeDialog
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val integrity = SecurityGuard.verifyIntegrity(this)
        if (integrity.isValid) {
            NexusRepository.init(this)
            ShizukuManager.init()
            TelemetryMonitor.start(this)
        }

        setContent {
            NexusSpaceTheme {
                if (!integrity.isValid) {
                    TamperLockScreen(result = integrity)
                } else {
                    NexusSpaceAppRoot()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        runCatching { ShizukuManager.refreshStatus() }
    }
}

@Composable
private fun NexusSpaceAppRoot() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val config by NexusRepository.config.collectAsStateWithLifecycle()
    val vipFeature by NexusRepository.vipDialogFeature.collectAsStateWithLifecycle()
    val statusToast by NexusRepository.statusToast.collectAsStateWithLifecycle()

    var currentSection by remember { mutableStateOf(DesktopSection.DESKTOP) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            if (Settings.canDrawOverlays(context)) {
                HudOverlayService.start(context)
            } else {
                NexusRepository.openOverlayPermissionSettings(context)
                NexusRepository.postToast("Conceda permissão de sobreposição para abrir o HUD.")
            }
        } else {
            if (Settings.canDrawOverlays(context)) {
                HudOverlayService.start(context)
            }
        }
    }

    LaunchedEffect(Unit) {
        NexusRepository.loadInstalledApps(context)
    }

    LaunchedEffect(statusToast) {
        if (statusToast != null) {
            delay(2800L)
            NexusRepository.clearToast()
        }
    }

    if (currentSection != DesktopSection.DESKTOP) {
        BackHandler {
            currentSection = DesktopSection.DESKTOP
        }
    }

    val toggleHudOverlay: () -> Unit = {
        if (config.isHudRunning) {
            HudOverlayService.stop(context)
            NexusRepository.postToast("HUD flutuante desativado.")
        } else {
            val needsNotif = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED

            if (needsNotif) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else if (!Settings.canDrawOverlays(context)) {
                NexusRepository.openOverlayPermissionSettings(context)
                NexusRepository.postToast("Ative 'Exibir sobre outros apps' para o HUD Flutuante.")
            } else {
                HudOverlayService.start(context)
                NexusRepository.postToast("HUD flutuante iniciado! Toque na alça lateral para expandir.")
            }
        }
    }

    val returnToNormalPhone: () -> Unit = {
        scope.launch {
            ShizukuManager.resetPhoneDisplay()
            runCatching {
                val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_HOME)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(homeIntent)
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        VirtualPcDesktopScreen(
            currentSection = currentSection,
            onNavigateSection = { currentSection = it },
            onToggleHudOverlay = toggleHudOverlay,
            onReturnToNormalPhone = returnToNormalPhone,
            contentOverlay = {
                when (currentSection) {
                    DesktopSection.GAME_SPACE -> ControlCenterScreen(
                        focusTabTitle = "NEXUS GAME SPACE",
                        onBackToDesktop = { currentSection = DesktopSection.DESKTOP },
                        onOpenWallpapers = { currentSection = DesktopSection.WALLPAPERS },
                        onToggleHudOverlay = toggleHudOverlay
                    )
                    DesktopSection.SETTINGS -> ControlCenterScreen(
                        focusTabTitle = "PAINEL SENSI & CONFIGURAÇÕES",
                        onBackToDesktop = { currentSection = DesktopSection.DESKTOP },
                        onOpenWallpapers = { currentSection = DesktopSection.WALLPAPERS },
                        onToggleHudOverlay = toggleHudOverlay
                    )
                    DesktopSection.WALLPAPERS -> WallpaperWindow(
                        onBackToDesktop = { currentSection = DesktopSection.DESKTOP }
                    )
                    DesktopSection.DESKTOP -> Unit
                }
            }
        )

        // In-app crosshair preview when HUD service is not active
        if (!config.isHudRunning && config.crosshairStyle != CrosshairStyle.NONE) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CrosshairCanvas(style = config.crosshairStyle, size = 40.dp, color = NexusCyan)
            }
        }

        // Non-blocking feedback pill
        AnimatedVisibility(
            visible = statusToast != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 64.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xF0101828))
                    .border(1.dp, NexusCyan, RoundedCornerShape(12.dp))
                    .padding(horizontal = 16.dp, vertical = 9.dp)
            ) {
                Text(
                    text = statusToast.orEmpty(),
                    color = NexusTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }

        // VIP Upgrade Dialog
        vipFeature?.let { featureName ->
            VipUpgradeDialog(
                featureContext = featureName,
                onDismiss = { NexusRepository.dismissVipDialog() },
                onOpenDiscord = { NexusRepository.openDiscordVip(context) }
            )
        }
    }
}
