package com.raylan.nexusspace.free.data

import androidx.compose.ui.graphics.ImageBitmap

const val DISCORD_VIP_URL = "https://discord.gg/DAjp6ZtXzZ"
const val OFFICIAL_CREDITS = "NEXUS SPACE FREE • Criado por Raylan"

enum class DesktopSection {
    DESKTOP,
    GAME_SPACE,
    SETTINGS,
    WALLPAPERS
}

enum class CrosshairStyle(val label: String) {
    NONE("Desligado"),
    DOT("Ponto"),
    CROSS("Cruz"),
    CIRCLE("Círculo")
}

enum class AnimationSpeed(val label: String, val scale: Float) {
    NORMAL("Normal", 1.0f),
    FAST("Rápida 0.5x", 0.5f),
    OFF("Desligada 0.0x", 0.0f)
}

enum class GameModeOption(val label: String, val description: String) {
    STANDARD("Padrão", "Perfil padrão do sistema"),
    BALANCED("Equilibrado", "Estabilidade de FPS e controle térmico")
}

data class InstalledAppInfo(
    val name: String,
    val packageName: String,
    val isPriorityGame: Boolean = false,
    val isInstalled: Boolean = true,
    val iconBitmap: ImageBitmap? = null
)

data class WallpaperOption(
    val id: String,
    val name: String,
    val drawableRes: Int? = null,
    val isVip: Boolean = false,
    val primaryHex: Long = 0xFF0A1428,
    val accentHex: Long = 0xFF00E5FF
)

data class TelemetrySnapshot(
    val fps: Int = 60,
    val cpuPercent: Int = 24,
    val ramPercent: Int = 48,
    val ramUsedMb: Long = 0L,
    val ramTotalMb: Long = 0L,
    val temperatureC: Float = 34.0f,
    val fpsHistory: List<Float> = List(20) { 60f }
)

data class ShizukuStatus(
    val isBinderAlive: Boolean = false,
    val isPermissionGranted: Boolean = false,
    val uid: Int = -1,
    val version: Int = -1
)

data class NexusConfigState(
    val selectedGamePackage: String = "com.dts.freefireth",
    val selectedGameName: String = "Free Fire",
    val refreshRateHz: Int = 60,
    val animationSpeed: AnimationSpeed = AnimationSpeed.FAST,
    val sensiMultiplier: Float = 1.00f,
    val quickTouchEnabled: Boolean = false,
    val crosshairStyle: CrosshairStyle = CrosshairStyle.NONE,
    val gameMode: GameModeOption = GameModeOption.BALANCED,
    val selectedWallpaperId: String = "wp_cyber_nexus",
    val isHudRunning: Boolean = false,
    val brightnessPercent: Int = 75,
    val volumePercent: Int = 70
)
