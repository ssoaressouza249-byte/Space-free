package com.raylan.nexusspace.free.ui.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.raylan.nexusspace.free.MainActivity
import com.raylan.nexusspace.free.R
import com.raylan.nexusspace.free.data.CrosshairStyle
import com.raylan.nexusspace.free.data.NexusRepository
import com.raylan.nexusspace.free.data.OFFICIAL_CREDITS
import com.raylan.nexusspace.free.shizuku.ShizukuManager
import com.raylan.nexusspace.free.telemetry.TelemetryMonitor
import com.raylan.nexusspace.free.ui.theme.CrosshairCanvas
import com.raylan.nexusspace.free.ui.theme.FpsSpeedometerGauge
import com.raylan.nexusspace.free.ui.theme.NexusAmber
import com.raylan.nexusspace.free.ui.theme.NexusCyan
import com.raylan.nexusspace.free.ui.theme.NexusEmerald
import com.raylan.nexusspace.free.ui.theme.NexusGold
import com.raylan.nexusspace.free.ui.theme.NexusLogoGlyph
import com.raylan.nexusspace.free.ui.theme.NexusSpaceTheme
import com.raylan.nexusspace.free.ui.theme.NexusTextPrimary
import com.raylan.nexusspace.free.ui.theme.NexusTextSecondary
import com.raylan.nexusspace.free.ui.theme.VipBannerButton
import com.raylan.nexusspace.free.ui.theme.VipHudLockCard
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private class OverlayLifecycleOwner : LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateController.savedStateRegistry

    fun performCreate() {
        savedStateController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
    }

    fun performDestroy() {
        runCatching {
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
            store.clear()
        }
    }
}

class HudOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var hudView: ComposeView? = null
    private var crosshairView: ComposeView? = null
    private var hudLayoutParams: WindowManager.LayoutParams? = null
    private var lifecycleOwner: OverlayLifecycleOwner? = null
    private val isExpandedState = mutableStateOf(false)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        NexusRepository.init(this)
        ShizukuManager.init()
        TelemetryMonitor.start(this)
        startForegroundNotification()
        if (Settings.canDrawOverlays(this)) {
            setupOverlays()
            NexusRepository.setHudRunning(true)
        } else {
            NexusRepository.postToast("Ative a permissão de sobreposição para abrir o HUD.")
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_HUD) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_EXPAND_HUD) {
            isExpandedState.value = true
            updateHudWindowParams(expanded = true)
        }
        return START_STICKY
    }

    private fun startForegroundNotification() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        val channelId = CHANNEL_ID
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager != null) {
                val channel = NotificationChannel(
                    channelId,
                    getString(R.string.hud_notification_channel_name),
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = getString(R.string.hud_notification_channel_desc)
                }
                manager.createNotificationChannel(channel)
            }
        }

        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, HudOverlayService::class.java).apply { action = ACTION_STOP_HUD },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(getString(R.string.hud_notification_title))
            .setContentText(getString(R.string.hud_notification_text))
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .addAction(0, "Fechar HUD", stopIntent)
            .build()

        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        }.onFailure {
            runCatching { startForeground(NOTIFICATION_ID, notification) }
        }
    }

    private fun setupOverlays() {
        runCatching {
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val owner = OverlayLifecycleOwner().apply { performCreate() }
            lifecycleOwner = owner

            val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }

            // 1. Non-touchable center crosshair window
            val crossParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.CENTER
            }

            val crossCompose = ComposeView(this).apply {
                setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
                setViewTreeLifecycleOwner(owner)
                setViewTreeViewModelStoreOwner(owner)
                setViewTreeSavedStateRegistryOwner(owner)
                setContent {
                    val cfg by NexusRepository.config.collectAsStateWithLifecycle()
                    if (cfg.crosshairStyle != CrosshairStyle.NONE) {
                        CrosshairCanvas(style = cfg.crosshairStyle, size = 42.dp, color = NexusCyan)
                    }
                }
            }
            crosshairView = crossCompose
            windowManager?.addView(crossCompose, crossParams)

            // 2. Floating HUD handle & expandable top panel
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                x = 0
                y = 18
            }
            hudLayoutParams = params

            val hudCompose = ComposeView(this).apply {
                setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
                setViewTreeLifecycleOwner(owner)
                setViewTreeViewModelStoreOwner(owner)
                setViewTreeSavedStateRegistryOwner(owner)
                setContent {
                    NexusSpaceTheme {
                        FloatingHudRoot(
                            expanded = isExpandedState.value,
                            onToggleExpand = { next ->
                                isExpandedState.value = next
                                updateHudWindowParams(expanded = next)
                            },
                            onDragDelta = { dx, dy ->
                                if (!isExpandedState.value) {
                                    updateHandlePosition(dx, dy)
                                }
                            },
                            onOpenPc = {
                                runCatching {
                                    val i = Intent(this@HudOverlayService, MainActivity::class.java).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                                    }
                                    startActivity(i)
                                }
                            },
                            onCloseHud = {
                                stopSelf()
                            }
                        )
                    }
                }
            }
            hudView = hudCompose
            windowManager?.addView(hudCompose, params)
        }.onFailure {
            stopSelf()
        }
    }

    private fun updateHandlePosition(dx: Int, dy: Int) {
        val params = hudLayoutParams ?: return
        val view = hudView ?: return
        runCatching {
            params.x += dx
            params.y = (params.y + dy).coerceAtLeast(8)
            windowManager?.updateViewLayout(view, params)
        }
    }

    private fun updateHudWindowParams(expanded: Boolean) {
        val params = hudLayoutParams ?: return
        val view = hudView ?: return
        runCatching {
            if (expanded) {
                params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                params.x = 0
                params.y = 14
                params.width = WindowManager.LayoutParams.WRAP_CONTENT
            } else {
                params.gravity = Gravity.TOP or Gravity.START
                params.x = 24
                params.y = 20
                params.width = WindowManager.LayoutParams.WRAP_CONTENT
            }
            windowManager?.updateViewLayout(view, params)
        }
    }

    override fun onDestroy() {
        NexusRepository.setHudRunning(false)
        runCatching {
            hudView?.let { windowManager?.removeView(it) }
            crosshairView?.let { windowManager?.removeView(it) }
            lifecycleOwner?.performDestroy()
        }
        hudView = null
        crosshairView = null
        lifecycleOwner = null
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "nexus_hud_overlay_channel"
        private const val NOTIFICATION_ID = 2026
        const val ACTION_STOP_HUD = "com.raylan.nexusspace.free.STOP_HUD"
        const val ACTION_EXPAND_HUD = "com.raylan.nexusspace.free.EXPAND_HUD"

        fun start(context: Context) {
            runCatching {
                val intent = Intent(context, HudOverlayService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            }
        }

        fun stop(context: Context) {
            runCatching {
                context.stopService(Intent(context, HudOverlayService::class.java))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun FloatingHudRoot(
    expanded: Boolean,
    onToggleExpand: (Boolean) -> Unit,
    onDragDelta: (Int, Int) -> Unit,
    onOpenPc: () -> Unit,
    onCloseHud: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val telemetry by TelemetryMonitor.telemetry.collectAsStateWithLifecycle()
    val config by NexusRepository.config.collectAsStateWithLifecycle()
    val shizukuFeedback by ShizukuManager.lastFeedback.collectAsStateWithLifecycle()

    var vipFeatureCardTitle by remember { mutableStateOf<String?>(null) }
    var brightnessSlider by remember(config.brightnessPercent) {
        mutableFloatStateOf(config.brightnessPercent.toFloat())
    }
    var volumeSlider by remember(config.volumePercent) {
        mutableFloatStateOf(config.volumePercent.toFloat())
    }

    if (!expanded) {
        // Edge Floating Handle (Alça Flutuante na Borda)
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0xEB0B111E), Color(0xEB14213B))
                    )
                )
                .border(1.2.dp, NexusCyan.copy(alpha = 0.85f), RoundedCornerShape(50))
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onDragDelta(dragAmount.x.roundToInt(), dragAmount.y.roundToInt())
                    }
                }
                .clickable { onToggleExpand(true) }
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .testTag("hud_floating_handle"),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            NexusLogoGlyph(size = 18.dp, tint = NexusCyan)
            Text(
                text = "HUD",
                color = NexusTextPrimary,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 11.sp
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(NexusEmerald.copy(alpha = 0.2f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "${telemetry.fps} FPS",
                    color = NexusEmerald,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
            Text(
                text = "${telemetry.temperatureC.roundToInt()}°C",
                color = NexusAmber,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp
            )
        }
    } else {
        // Top Floating In-Game HUD Panel
        Column(
            modifier = Modifier
                .widthIn(min = 500.dp, max = 660.dp)
                .padding(horizontal = 8.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xF50B101C), Color(0xF511192B))
                    )
                )
                .border(1.5.dp, NexusCyan.copy(alpha = 0.65f), RoundedCornerShape(18.dp))
                .padding(12.dp)
                .testTag("hud_expanded_panel"),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header with VIP banner + collapse/close
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    NexusLogoGlyph(size = 20.dp, tint = NexusCyan)
                    Column {
                        Text(
                            text = "NEXUS HUD • ${config.selectedGameName}",
                            color = NexusTextPrimary,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = shizukuFeedback,
                            color = NexusCyan,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    VipBannerButton(
                        text = "★ OBTER NEXUS SPACE VIP",
                        compact = true,
                        onClick = { vipFeatureCardTitle = "NEXUS SPACE VIP Completo" }
                    )
                    IconButton(
                        onClick = { onToggleExpand(false) },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1D2840))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Minimizar HUD",
                            tint = NexusTextPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Live FPS Speedometer + CPU % & RAM % + Sliders
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Circular FPS Gauge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF0A0F1A))
                        .border(1.dp, Color(0x3300E5FF), RoundedCornerShape(14.dp))
                        .padding(10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    FpsSpeedometerGauge(
                        fps = telemetry.fps,
                        targetMaxFps = config.refreshRateHz,
                        size = 74.dp
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${telemetry.fps}",
                            color = NexusEmerald,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "FPS",
                            color = NexusTextSecondary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // CPU & RAM Bars
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF0A0F1A))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("CPU", color = NexusTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("${telemetry.cpuPercent}%", color = NexusCyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    LinearProgressIndicator(
                        progress = { telemetry.cpuPercent / 100f },
                        color = NexusCyan,
                        trackColor = Color(0xFF1F2A44),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(4.dp))
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("RAM (${telemetry.ramUsedMb}MB)", color = NexusTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("${telemetry.ramPercent}%", color = NexusEmerald, fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    LinearProgressIndicator(
                        progress = { telemetry.ramPercent / 100f },
                        color = NexusEmerald,
                        trackColor = Color(0xFF1F2A44),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(4.dp))
                    )
                    Text(
                        text = "Temp: ${"%.1f".format(telemetry.temperatureC)} °C • Tela: ${config.refreshRateHz} Hz",
                        color = NexusAmber,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                }

                // Brightness & Volume Sliders
                Column(
                    modifier = Modifier
                        .weight(1.1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF0A0F1A))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Brilho", color = NexusTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        Text("${brightnessSlider.roundToInt()}%", color = NexusCyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                    Slider(
                        value = brightnessSlider,
                        onValueChange = {
                            brightnessSlider = it
                            val pct = it.roundToInt()
                            NexusRepository.updateConfig { cfg -> cfg.copy(brightnessPercent = pct) }
                            scope.launch { TelemetryMonitor.setBrightnessPercent(context, pct) }
                        },
                        valueRange = 5f..100f,
                        colors = SliderDefaults.colors(
                            thumbColor = NexusCyan,
                            activeTrackColor = NexusCyan
                        ),
                        modifier = Modifier.height(28.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Volume", color = NexusTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        Text("${volumeSlider.roundToInt()}%", color = NexusEmerald, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                    Slider(
                        value = volumeSlider,
                        onValueChange = {
                            volumeSlider = it
                            val pct = it.roundToInt()
                            NexusRepository.updateConfig { cfg -> cfg.copy(volumePercent = pct) }
                            TelemetryMonitor.setVolumePercent(context, pct)
                        },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(
                            thumbColor = NexusEmerald,
                            activeTrackColor = NexusEmerald
                        ),
                        modifier = Modifier.height(28.dp)
                    )
                }
            }

            // Free Quick Buttons
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                HudActionChip(
                    label = "Turbo Grátis",
                    accent = NexusEmerald,
                    onClick = {
                        scope.launch {
                            ShizukuManager.applyTurboFree(context, config.selectedGamePackage)
                        }
                    }
                )
                HudActionChip(
                    label = "Limpar RAM",
                    accent = NexusCyan,
                    onClick = {
                        scope.launch { ShizukuManager.cleanRamAndCache(context) }
                    }
                )
                HudActionChip(
                    label = "Crosshair: ${config.crosshairStyle.label}",
                    accent = NexusCyan,
                    onClick = {
                        val values = CrosshairStyle.entries
                        val next = values[(values.indexOf(config.crosshairStyle) + 1) % values.size]
                        NexusRepository.updateConfig { it.copy(crosshairStyle = next) }
                    }
                )
                HudActionChip(
                    label = "Sensi 1.4x",
                    accent = NexusCyan,
                    onClick = {
                        NexusRepository.updateConfig { it.copy(sensiMultiplier = 1.40f, quickTouchEnabled = true) }
                        scope.launch { ShizukuManager.setSensiMultiplier(1.40f) }
                    }
                )
                HudActionChip(
                    label = if (config.refreshRateHz >= 90) "90 Hz Ativo" else "60/90 Hz",
                    accent = NexusCyan,
                    onClick = {
                        val nextHz = if (config.refreshRateHz >= 90) 60 else 90
                        NexusRepository.updateConfig { it.copy(refreshRateHz = nextHz) }
                        scope.launch { ShizukuManager.setRefreshRate(nextHz) }
                    }
                )
                HudActionChip(
                    label = "Ir ao PC",
                    accent = Color(0xFF7B9CFF),
                    onClick = {
                        onToggleExpand(false)
                        onOpenPc()
                    }
                )
                HudActionChip(
                    label = "Fechar HUD",
                    accent = Color(0xFFFF5252),
                    onClick = onCloseHud
                )
            }

            // VIP Locked Quick Buttons
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                HudVipChip("120 FPS Extremo 🔒") { vipFeatureCardTitle = "120 FPS Extremo" }
                HudVipChip("Gráfico Liso 🔒") { vipFeatureCardTitle = "Gráfico Liso OpenGL" }
                HudVipChip("Resolução 🔒") { vipFeatureCardTitle = "Resolução Livre Customizada" }
                HudVipChip("Modo Gelo 🔒") { vipFeatureCardTitle = "Modo Gelo (Resfriamento Profundo)" }
            }

            vipFeatureCardTitle?.let { title ->
                VipHudLockCard(
                    featureTitle = title,
                    onDismiss = { vipFeatureCardTitle = null },
                    onOpenDiscord = { NexusRepository.openDiscordVip(context) }
                )
            }

            Text(
                text = OFFICIAL_CREDITS,
                color = NexusTextSecondary.copy(alpha = 0.7f),
                fontSize = 9.sp,
                modifier = Modifier.align(Alignment.End)
            )
        }
    }
}

@Composable
private fun HudActionChip(
    label: String,
    accent: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(accent.copy(alpha = 0.16f))
            .border(1.dp, accent.copy(alpha = 0.65f), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = NexusTextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            maxLines = 1
        )
    }
}

@Composable
private fun HudVipChip(
    label: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(NexusGold.copy(alpha = 0.12f))
            .border(1.dp, NexusGold.copy(alpha = 0.65f), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Lock,
            contentDescription = null,
            tint = NexusGold,
            modifier = Modifier.size(12.dp)
        )
        Text(
            text = label,
            color = NexusGold,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 11.sp,
            maxLines = 1
        )
    }
}
