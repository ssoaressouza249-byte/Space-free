package com.raylan.nexusspace.free.ui.gamespace

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.raylan.nexusspace.free.data.AnimationSpeed
import com.raylan.nexusspace.free.data.CrosshairStyle
import com.raylan.nexusspace.free.data.GameModeOption
import com.raylan.nexusspace.free.data.NexusRepository
import com.raylan.nexusspace.free.data.OFFICIAL_CREDITS
import com.raylan.nexusspace.free.shizuku.ShizukuManager
import com.raylan.nexusspace.free.telemetry.TelemetryMonitor
import com.raylan.nexusspace.free.ui.theme.CrosshairCanvas
import com.raylan.nexusspace.free.ui.theme.GamepadGlyph
import com.raylan.nexusspace.free.ui.theme.IceCrystalGlyph
import com.raylan.nexusspace.free.ui.theme.NexusAmber
import com.raylan.nexusspace.free.ui.theme.NexusBlueAccent
import com.raylan.nexusspace.free.ui.theme.NexusCrimson
import com.raylan.nexusspace.free.ui.theme.NexusCyan
import com.raylan.nexusspace.free.ui.theme.NexusEmerald
import com.raylan.nexusspace.free.ui.theme.NexusGold
import com.raylan.nexusspace.free.ui.theme.NexusLogoGlyph
import com.raylan.nexusspace.free.ui.theme.NexusSurfaceCard
import com.raylan.nexusspace.free.ui.theme.NexusSurfaceDark
import com.raylan.nexusspace.free.ui.theme.NexusTextMuted
import com.raylan.nexusspace.free.ui.theme.NexusTextPrimary
import com.raylan.nexusspace.free.ui.theme.NexusTextSecondary
import com.raylan.nexusspace.free.ui.theme.TurboLightningGlyph
import com.raylan.nexusspace.free.ui.theme.VipBannerButton
import com.raylan.nexusspace.free.ui.theme.VipCrownGlyph
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun ControlCenterScreen(
    focusTabTitle: String,
    onBackToDesktop: () -> Unit,
    onOpenWallpapers: () -> Unit,
    onToggleHudOverlay: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val config by NexusRepository.config.collectAsStateWithLifecycle()
    val telemetry by TelemetryMonitor.telemetry.collectAsStateWithLifecycle()
    val shizukuStatus by ShizukuManager.status.collectAsStateWithLifecycle()
    val shizukuFeedback by ShizukuManager.lastFeedback.collectAsStateWithLifecycle()
    val installedApps by NexusRepository.installedApps.collectAsStateWithLifecycle()

    var sensiSlider by remember(config.sensiMultiplier) {
        mutableFloatStateOf(config.sensiMultiplier)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xE6070B14))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Window Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(NexusSurfaceDark)
                .border(1.dp, NexusCyan.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                IconButton(
                    onClick = onBackToDesktop,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(NexusSurfaceCard)
                        .testTag("back_to_desktop_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Voltar ao PC Virtual",
                        tint = NexusCyan
                    )
                }
                NexusLogoGlyph(size = 24.dp)
                Column {
                    Text(
                        text = "CENTRAL DE CONFIGURAÇÕES • $focusTabTitle",
                        color = NexusTextPrimary,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Alvo: ${config.selectedGameName} (${config.selectedGamePackage})",
                        color = NexusCyan,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Shizuku Quick Status Pill
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            if (shizukuStatus.isPermissionGranted) NexusEmerald.copy(alpha = 0.16f)
                            else NexusAmber.copy(alpha = 0.16f)
                        )
                        .border(
                            1.dp,
                            if (shizukuStatus.isPermissionGranted) NexusEmerald else NexusAmber,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { ShizukuManager.requestPermission() }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (shizukuStatus.isPermissionGranted) "SHIZUKU UID ${shizukuStatus.uid}" else "ATIVAR SHIZUKU",
                        color = if (shizukuStatus.isPermissionGranted) NexusEmerald else NexusAmber,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }

                Button(
                    onClick = onToggleHudOverlay,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (config.isHudRunning) NexusCrimson else NexusCyan,
                        contentColor = Color(0xFF00141A)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .height(38.dp)
                        .testTag("toggle_hud_from_settings_button")
                ) {
                    Text(
                        text = if (config.isHudRunning) "Fechar HUD" else "Abrir HUD",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 11.sp
                    )
                }

                VipBannerButton(
                    compact = true,
                    onClick = { NexusRepository.showVipDialog("NEXUS SPACE VIP") }
                )
            }
        }

        // 3 HORIZONTAL COLUMNS
        Row(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // COLUMN 1: 7 FREE SHIZUKU SYSTEM OPTIMIZATIONS (#1 to #7)
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(16.dp))
                    .background(NexusSurfaceDark.copy(alpha = 0.94f))
                    .border(1.dp, NexusEmerald.copy(alpha = 0.30f), RoundedCornerShape(16.dp))
                    .padding(12.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ColumnHeader(
                    title = "SISTEMA SHIZUKU (GRÁTIS)",
                    subtitle = "Funções reais Shell UID 2000",
                    accent = NexusEmerald
                )

                // Active Game Selector Strip
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    installedApps.filter { it.isPriorityGame }.take(3).forEach { game ->
                        val selected = config.selectedGamePackage == game.packageName
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selected) NexusCyan.copy(alpha = 0.22f) else NexusSurfaceCard)
                                .border(
                                    1.dp,
                                    if (selected) NexusCyan else Color(0x22FFFFFF),
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    NexusRepository.updateConfig {
                                        it.copy(
                                            selectedGamePackage = game.packageName,
                                            selectedGameName = game.name
                                        )
                                    }
                                }
                                .padding(vertical = 6.dp, horizontal = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = game.name,
                                color = if (selected) NexusCyan else NexusTextSecondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                // 1. Limpeza de RAM e Cache
                FreeFunctionCard(
                    number = "1",
                    title = "Limpeza de RAM e Cache",
                    commandHint = "pm trim-caches 999G + am kill-all",
                    actionLabel = "LIMPAR",
                    accent = NexusEmerald,
                    onClick = { scope.launch { ShizukuManager.cleanRamAndCache(context) } }
                )

                // 2. Compilação Rápida do Jogo
                FreeFunctionCard(
                    number = "2",
                    title = "Compilação Rápida do Jogo",
                    commandHint = "compile -m speed-profile -f ${config.selectedGameName}",
                    actionLabel = "COMPILAR",
                    accent = NexusEmerald,
                    onClick = { scope.launch { ShizukuManager.compileGameFast(config.selectedGamePackage) } }
                )

                // 3. Bloquear Apps em 2º Plano
                FreeFunctionCard(
                    number = "3",
                    title = "Bloquear Apps em 2º Plano",
                    commandHint = "cmd appops set --all RUN_IN_BACKGROUND ignore",
                    actionLabel = "BLOQUEAR",
                    accent = NexusCyan,
                    onClick = { scope.launch { ShizukuManager.blockBackgroundApps() } }
                )

                // 4. Animações do Sistema
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(NexusSurfaceCard)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "4. Animações do Sistema",
                        color = NexusTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AnimationSpeed.entries.forEach { speed ->
                            val active = config.animationSpeed == speed
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (active) NexusCyan else Color(0xFF0E1422))
                                    .clickable {
                                        NexusRepository.updateConfig { it.copy(animationSpeed = speed) }
                                        scope.launch { ShizukuManager.setAnimationsScale(speed) }
                                    }
                                    .padding(vertical = 7.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = speed.label,
                                    color = if (active) Color(0xFF00141A) else NexusTextSecondary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                // 5. Otimizar Standby Bucket
                FreeFunctionCard(
                    number = "5",
                    title = "Otimizar Standby Bucket",
                    commandHint = "am set-standby-bucket ${config.selectedGameName} active",
                    actionLabel = "PRIORIZAR",
                    accent = NexusCyan,
                    onClick = { scope.launch { ShizukuManager.optimizeStandbyBucket(config.selectedGamePackage) } }
                )

                // 6. Limpar Logs do Sistema
                FreeFunctionCard(
                    number = "6",
                    title = "Limpar Logs do Sistema",
                    commandHint = "logcat -c",
                    actionLabel = "LIMPAR",
                    accent = NexusBlueAccent,
                    onClick = { scope.launch { ShizukuManager.clearSystemLogs() } }
                )

                // 7. Limpar Cache DNS
                FreeFunctionCard(
                    number = "7",
                    title = "Limpar Cache DNS",
                    commandHint = "ndc resolver clearnetdns",
                    actionLabel = "FLUSH DNS",
                    accent = NexusBlueAccent,
                    onClick = { scope.launch { ShizukuManager.clearDnsCache() } }
                )
            }

            // COLUMN 2: SCREEN, SENSI & GAME SPACE (#8 to #14)
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(16.dp))
                    .background(NexusSurfaceDark.copy(alpha = 0.94f))
                    .border(1.dp, NexusCyan.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                    .padding(12.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ColumnHeader(
                    title = "TELA, SENSI & GAME SPACE",
                    subtitle = "Controles visuais e resposta tátil (Grátis)",
                    accent = NexusCyan
                )

                // 8. Taxa de Atualização 60 Hz e 90 Hz
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(NexusSurfaceCard)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "8. Taxa de Atualização (Grátis)",
                        color = NexusTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(60, 90).forEach { hz ->
                            val selected = config.refreshRateHz == hz
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (selected) NexusCyan else Color(0xFF0E1422))
                                    .clickable {
                                        NexusRepository.updateConfig { it.copy(refreshRateHz = hz) }
                                        scope.launch { ShizukuManager.setRefreshRate(hz) }
                                    }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$hz Hz",
                                    color = if (selected) Color(0xFF00141A) else NexusTextPrimary,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }

                // 9. Sensi X/Y Básica (0.50x até 1.40x) & 10. Toque Rápido
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(NexusSurfaceCard)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "9. Sensi X/Y Básica",
                            color = NexusTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "${"%.2f".format(sensiSlider)}x",
                            color = NexusCyan,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.sp
                        )
                    }
                    Slider(
                        value = sensiSlider,
                        onValueChange = { sensiSlider = it },
                        onValueChangeFinished = {
                            NexusRepository.updateConfig { it.copy(sensiMultiplier = sensiSlider) }
                            scope.launch { ShizukuManager.setSensiMultiplier(sensiSlider) }
                        },
                        valueRange = 0.50f..1.40f,
                        colors = SliderDefaults.colors(thumbColor = NexusCyan, activeTrackColor = NexusCyan),
                        modifier = Modifier.height(28.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "10. Toque Rápido (pointer_speed 5)",
                            color = NexusTextSecondary,
                            fontSize = 11.sp
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (config.quickTouchEnabled) NexusEmerald else NexusCyan.copy(alpha = 0.20f))
                                .clickable {
                                    NexusRepository.updateConfig { it.copy(quickTouchEnabled = true, sensiMultiplier = 1.25f) }
                                    sensiSlider = 1.25f
                                    scope.launch { ShizukuManager.enableQuickTouch() }
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (config.quickTouchEnabled) "ATIVO" else "ATIVAR",
                                color = if (config.quickTouchEnabled) Color(0xFF00210E) else NexusCyan,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 10.sp
                            )
                        }
                    }
                }

                // 11. Crosshair Visual Central (Ponto, Cruz, Círculo)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(NexusSurfaceCard)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "11. Crosshair Visual Central",
                            color = NexusTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        CrosshairCanvas(style = config.crosshairStyle, size = 24.dp, color = NexusCyan)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        CrosshairStyle.entries.forEach { style ->
                            val active = config.crosshairStyle == style
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (active) NexusCyan else Color(0xFF0E1422))
                                    .clickable {
                                        NexusRepository.updateConfig { it.copy(crosshairStyle = style) }
                                    }
                                    .padding(vertical = 7.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = style.label,
                                    color = if (active) Color(0xFF00141A) else NexusTextSecondary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                // 12. Modo de Jogo (Padrão e Equilibrado)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(NexusSurfaceCard)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "12. Modo de Jogo",
                        color = NexusTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GameModeOption.entries.forEach { mode ->
                            val active = config.gameMode == mode
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (active) NexusEmerald.copy(alpha = 0.20f) else Color(0xFF0E1422))
                                    .border(1.dp, if (active) NexusEmerald else Color.Transparent, RoundedCornerShape(8.dp))
                                    .clickable {
                                        NexusRepository.updateConfig { it.copy(gameMode = mode) }
                                        scope.launch { ShizukuManager.setGameMode(config.selectedGamePackage, mode) }
                                    }
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = mode.label,
                                    color = if (active) NexusEmerald else NexusTextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = mode.description,
                                    color = NexusTextMuted,
                                    fontSize = 9.sp,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }

                // 13. Monitor de Telemetria ao Vivo
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(NexusSurfaceCard)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "13. Monitor de Telemetria ao Vivo",
                        color = NexusTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TelemetryChip("FPS", "${telemetry.fps}", NexusEmerald)
                        TelemetryChip("CPU", "${telemetry.cpuPercent}%", NexusCyan)
                        TelemetryChip("RAM", "${telemetry.ramPercent}%", NexusBlueAccent)
                        TelemetryChip("TEMP", "${"%.1f".format(telemetry.temperatureC)}°C", NexusAmber)
                    }
                    FpsSparkline(history = telemetry.fpsHistory, modifier = Modifier.fillMaxWidth().height(34.dp))
                }

                // 14. 3 Papéis de Parede Grátis para o PC Virtual
                FreeFunctionCard(
                    number = "14",
                    title = "3 Papéis de Parede Grátis",
                    commandHint = "Personalize o fundo do PC Virtual",
                    actionLabel = "ABRIR",
                    accent = NexusCyan,
                    onClick = onOpenWallpapers
                )
            }

            // COLUMN 3: 6 ELITE VIP LOCKED FEATURES
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xF0151412), Color(0xF00D0F18))
                        )
                    )
                    .border(1.5.dp, NexusGold.copy(alpha = 0.55f), RoundedCornerShape(16.dp))
                    .padding(12.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ColumnHeader(
                        title = "RECURSOS DE ELITE VIP",
                        subtitle = "Desempenho extremo no Discord",
                        accent = NexusGold
                    )
                    VipCrownGlyph(size = 20.dp)
                }

                VipLockedCard(
                    number = "1",
                    title = "Taxa de atualização 120 Hz e 144 Hz",
                    subtitle = "Desbloqueia refresh rate competitivo máximo",
                    onClick = { NexusRepository.showVipDialog("Taxa de atualização 120 Hz e 144 Hz") }
                )
                VipLockedCard(
                    number = "2",
                    title = "Gráfico Liso OpenGL & Downscale 50% a 85%",
                    subtitle = "Reduz serrilhado e alivia GPU em 40%",
                    onClick = { NexusRepository.showVipDialog("Gráfico Liso OpenGL & Downscale 50%-85%") }
                )
                VipLockedCard(
                    number = "3",
                    title = "Limite de FPS 120 e Máx",
                    subtitle = "cmd game set --fps 120 + swapinterval 0",
                    onClick = { NexusRepository.showVipDialog("Limite de FPS 120 e Máx") }
                )
                VipLockedCard(
                    number = "4",
                    title = "Resolução Livre Customizada",
                    subtitle = "Ajuste fino wm size & DPI por jogo",
                    onClick = { NexusRepository.showVipDialog("Resolução Livre Customizada (wm size)") }
                )
                VipLockedCard(
                    number = "5",
                    title = "Compilação Zero-Logo, Sensi Pro & Toque 0ms",
                    subtitle = "compile -m everything • Sensi 1.45x a 2.00x",
                    onClick = { NexusRepository.showVipDialog("Compilação Zero-Logo, Sensi Pro 2.00x & Toque 0ms") }
                )
                VipLockedCard(
                    number = "6",
                    title = "Modo Gelo (Resfriamento Profundo)",
                    subtitle = "thermalservice override-status 0 + controle térmico",
                    onClick = { NexusRepository.showVipDialog("Modo Gelo (Resfriamento Profundo)") }
                )

                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = { NexusRepository.openDiscordVip(context) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NexusGold,
                        contentColor = Color(0xFF1A1200)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("column_vip_discord_button")
                ) {
                    Text(
                        text = "COMPRAR VIP NO DISCORD",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Bottom Console Status + Official Credits
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(NexusSurfaceDark)
                .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "SHELL > $shizukuFeedback",
                color = NexusCyan,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = OFFICIAL_CREDITS,
                color = NexusTextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun ColumnHeader(title: String, subtitle: String, accent: Color) {
    Column {
        Text(
            text = title,
            color = accent,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 13.sp,
            letterSpacing = 0.5.sp
        )
        Text(
            text = subtitle,
            color = NexusTextSecondary,
            fontSize = 10.sp
        )
    }
}

@Composable
private fun FreeFunctionCard(
    number: String,
    title: String,
    commandHint: String,
    actionLabel: String,
    accent: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(NexusSurfaceCard)
            .border(1.dp, accent.copy(alpha = 0.22f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "$number. $title",
                color = NexusTextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = commandHint,
                color = NexusTextMuted,
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(accent.copy(alpha = 0.18f))
                .border(1.dp, accent.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                .padding(horizontal = 9.dp, vertical = 6.dp)
        ) {
            Text(
                text = actionLabel,
                color = accent,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
private fun VipLockedCard(
    number: String,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF1A1710))
            .border(1.dp, NexusGold.copy(alpha = 0.48f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "$number. $title",
                color = NexusGold,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                color = Color(0xFFD6C38A),
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(NexusGold.copy(alpha = 0.22f))
                .padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                tint = NexusGold,
                modifier = Modifier.size(12.dp)
            )
            Text(
                text = "VIP 🔒",
                color = NexusGold,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
private fun TelemetryChip(label: String, value: String, color: Color) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF0E1422))
            .padding(horizontal = 8.dp, vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, color = NexusTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, color = color, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
    }
}

@Composable
private fun FpsSparkline(history: List<Float>, modifier: Modifier = Modifier) {
    Canvas(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF0A0F1A))
    ) {
        if (history.size < 2) return@Canvas
        val maxVal = (history.maxOrNull() ?: 90f).coerceAtLeast(60f)
        val stepX = size.width / (history.size - 1)
        val path = Path()
        history.forEachIndexed { idx, value ->
            val x = idx * stepX
            val ratio = (value / maxVal).coerceIn(0f, 1f)
            val y = size.height - (ratio * (size.height - 8f)) - 4f
            if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path = path, color = NexusEmerald, style = Stroke(width = 3f))
    }
}
