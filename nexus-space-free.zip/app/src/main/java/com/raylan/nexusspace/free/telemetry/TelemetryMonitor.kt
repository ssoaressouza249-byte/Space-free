package com.raylan.nexusspace.free.telemetry

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.view.Choreographer
import android.view.WindowManager
import com.raylan.nexusspace.free.data.TelemetrySnapshot
import com.raylan.nexusspace.free.shizuku.ShizukuManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.RandomAccessFile
import kotlin.math.roundToInt

object TelemetryMonitor {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var monitorJob: Job? = null
    private var appContext: Context? = null

    private val _telemetry = MutableStateFlow(TelemetrySnapshot())
    val telemetry: StateFlow<TelemetrySnapshot> = _telemetry.asStateFlow()

    @Volatile
    private var frameCount = 0
    @Volatile
    private var lastFpsWindowNs = 0L
    @Volatile
    private var measuredFps = 60
    @Volatile
    private var choreographerRegistered = false

    private var prevCpuTotal = 0L
    private var prevCpuIdle = 0L
    private var prevProcCpuMs = 0L
    private var prevWallMs = 0L

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (lastFpsWindowNs == 0L) {
                lastFpsWindowNs = frameTimeNanos
            }
            frameCount++
            val elapsedNs = frameTimeNanos - lastFpsWindowNs
            if (elapsedNs >= 500_000_000L) {
                val fps = ((frameCount * 1_000_000_000.0) / elapsedNs).roundToInt()
                measuredFps = fps.coerceIn(1, 240)
                frameCount = 0
                lastFpsWindowNs = frameTimeNanos
            }
            if (choreographerRegistered) {
                runCatching { Choreographer.getInstance().postFrameCallback(this) }
            }
        }
    }

    fun start(context: Context) {
        appContext = context.applicationContext
        if (!choreographerRegistered) {
            choreographerRegistered = true
            scope.launch(Dispatchers.Main) {
                runCatching {
                    Choreographer.getInstance().postFrameCallback(frameCallback)
                }
            }
        }
        if (monitorJob?.isActive == true) return
        monitorJob = scope.launch {
            while (isActive) {
                val ctx = appContext ?: break
                val snapshot = collectSnapshot(ctx)
                _telemetry.value = snapshot
                delay(1000L)
            }
        }
    }

    private fun collectSnapshot(context: Context): TelemetrySnapshot {
        val (ramPct, usedMb, totalMb) = readRamStats(context)
        val cpuPct = readCpuPercent()
        val tempC = readTemperatureC(context)
        val maxDisplayHz = readDisplayRefreshRate(context)
        val currentFps = measuredFps.coerceAtMost(maxDisplayHz.coerceAtLeast(60))
        val prevHistory = _telemetry.value.fpsHistory
        val nextHistory = (prevHistory.drop(1) + currentFps.toFloat())
        return TelemetrySnapshot(
            fps = currentFps,
            cpuPercent = cpuPct,
            ramPercent = ramPct,
            ramUsedMb = usedMb,
            ramTotalMb = totalMb,
            temperatureC = tempC,
            fpsHistory = nextHistory
        )
    }

    private fun readDisplayRefreshRate(context: Context): Int {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                wm.maximumWindowMetrics.bounds
                @Suppress("DEPRECATION")
                wm.defaultDisplay.refreshRate.roundToInt()
            } else {
                val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                @Suppress("DEPRECATION")
                wm.defaultDisplay.refreshRate.roundToInt()
            }
        }.getOrDefault(60)
    }

    private fun readRamStats(context: Context): Triple<Int, Long, Long> {
        return runCatching {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)
            val totalMb = (memInfo.totalMem / (1024L * 1024L)).coerceAtLeast(1L)
            val availMb = memInfo.availMem / (1024L * 1024L)
            val usedMb = (totalMb - availMb).coerceAtLeast(0L)
            val pct = ((usedMb * 100f) / totalMb).roundToInt().coerceIn(0, 100)
            Triple(pct, usedMb, totalMb)
        }.getOrDefault(Triple(45, 2048L, 4096L))
    }

    private fun readCpuPercent(): Int {
        val procStatResult = runCatching {
            RandomAccessFile("/proc/stat", "r").use { raf ->
                val line = raf.readLine() ?: return@use null
                val parts = line.trim().split(Regex("\\s+"))
                if (parts.size < 5 || parts[0] != "cpu") return@use null
                val user = parts[1].toLongOrNull() ?: 0L
                val nice = parts[2].toLongOrNull() ?: 0L
                val system = parts[3].toLongOrNull() ?: 0L
                val idle = parts[4].toLongOrNull() ?: 0L
                val iowait = parts.getOrNull(5)?.toLongOrNull() ?: 0L
                val irq = parts.getOrNull(6)?.toLongOrNull() ?: 0L
                val softirq = parts.getOrNull(7)?.toLongOrNull() ?: 0L
                val total = user + nice + system + idle + iowait + irq + softirq
                val totalIdle = idle + iowait
                if (prevCpuTotal == 0L) {
                    prevCpuTotal = total
                    prevCpuIdle = totalIdle
                    return@use 18
                }
                val diffTotal = (total - prevCpuTotal).coerceAtLeast(1L)
                val diffIdle = (totalIdle - prevCpuIdle).coerceAtLeast(0L)
                prevCpuTotal = total
                prevCpuIdle = totalIdle
                (((diffTotal - diffIdle) * 100f) / diffTotal).roundToInt().coerceIn(1, 100)
            }
        }.getOrNull()

        if (procStatResult != null) return procStatResult

        // Fallback via Process elapsed CPU time + loadavg / cores when /proc/stat is restricted
        return runCatching {
            val nowMs = System.currentTimeMillis()
            val procCpuMs = Process.getElapsedCpuTime()
            val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
            val pct = if (prevWallMs == 0L) {
                16
            } else {
                val wallDelta = (nowMs - prevWallMs).coerceAtLeast(1L) * cores
                val cpuDelta = (procCpuMs - prevProcCpuMs).coerceAtLeast(0L)
                ((cpuDelta * 100f) / wallDelta).roundToInt().coerceIn(4, 98)
            }
            prevWallMs = nowMs
            prevProcCpuMs = procCpuMs
            pct
        }.getOrDefault(20)
    }

    private fun readTemperatureC(context: Context): Float {
        val batteryTemp = runCatching {
            val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val tenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 340) ?: 340
            (tenths / 10f).coerceIn(15f, 85f)
        }.getOrNull()
        if (batteryTemp != null) return batteryTemp

        return runCatching {
            RandomAccessFile("/sys/class/thermal/thermal_zone0/temp", "r").use { raf ->
                val raw = raf.readLine()?.trim()?.toFloatOrNull() ?: 34000f
                if (raw > 1000f) raw / 1000f else raw
            }
        }.getOrDefault(34.5f)
    }

    fun getCurrentBrightnessPercent(context: Context): Int {
        return runCatching {
            val value = Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 180)
            ((value / 255f) * 100f).roundToInt().coerceIn(5, 100)
        }.getOrDefault(75)
    }

    suspend fun setBrightnessPercent(context: Context, percent: Int) {
        val clamped = percent.coerceIn(5, 100)
        val raw = ((clamped / 100f) * 255f).roundToInt().coerceIn(10, 255)
        val wroteDirect = runCatching {
            if (Settings.System.canWrite(context)) {
                Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, raw)
                true
            } else {
                false
            }
        }.getOrDefault(false)

        if (!wroteDirect) {
            ShizukuManager.runCommand("settings put system screen_brightness_mode 0 && settings put system screen_brightness $raw")
        }
    }

    fun getCurrentVolumePercent(context: Context): Int {
        return runCatching {
            val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val current = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            ((current * 100f) / max).roundToInt().coerceIn(0, 100)
        }.getOrDefault(70)
    }

    fun setVolumePercent(context: Context, percent: Int) {
        runCatching {
            val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val target = ((percent.coerceIn(0, 100) / 100f) * max).roundToInt().coerceIn(0, max)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
        }
    }
}
