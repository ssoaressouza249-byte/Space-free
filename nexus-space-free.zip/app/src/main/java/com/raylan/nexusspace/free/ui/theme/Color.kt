package com.raylan.nexusspace.free.ui.theme

import androidx.compose.ui.graphics.Color

val NexusObsidianBg = Color(0xFF070A11)
val NexusSurfaceDark = Color(0xFF0E1422)
val NexusSurfaceCard = Color(0xFF151D30)
val NexusSurfaceElevated = Color(0xFF1D2740)
val NexusGlassBorder = Color(0x3370B5FF)

val NexusCyan = Color(0xFF00E5FF)
val NexusCyanDim = Color(0xFF0099B8)
val NexusBlueAccent = Color(0xFF3D7EFF)
val NexusEmerald = Color(0xFF00E676)
val NexusGold = Color(0xFFFFD700)
val NexusGoldDeep = Color(0xFFFFA000)
val NexusCrimson = Color(0xFFFF3D57)
val NexusAmber = Color(0xFFFFB300)

val NexusTextPrimary = Color(0xFFF2F6FF)
val NexusTextSecondary = Color(0xFF94A3B8)
val NexusTextMuted = Color(0xFF64748B)
