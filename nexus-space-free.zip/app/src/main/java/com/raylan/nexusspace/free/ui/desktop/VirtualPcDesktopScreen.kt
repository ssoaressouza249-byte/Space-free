package com.raylan.nexusspace.free.ui.desktop

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.raylan.nexusspace.free.R
import com.raylan.nexusspace.free.data.DesktopSection
import com.raylan.nexusspace.free.data.InstalledAppInfo
import com.raylan.nexusspace.free.data.NexusRepository
import com.raylan.nexusspace.free.data.OFFICIAL_CREDITS
import com.raylan.nexusspace.free.shizuku.ShizukuManager
import com.raylan.nexusspace.free.telemetry.TelemetryMonitor
import com.raylan.nexusspace.free.ui.theme.CrosshairCanvas
import com.raylan.nexusspace.free.ui.theme.GamepadGlyph
import com.raylan.nexusspace.free.ui.theme.IceCrystalGlyph
import com.raylan.nexusspace.free.ui.theme.NexusAmber
import com.raylan.nexusspace.free.ui.theme.NexusBlueAccent
import com.raylan.nexusspace.free.ui.theme.NexusCrimson
import com.raylan.nexusspace.free.ui.theme.NexusCyan
import com.raylan.nexusspace.free.ui.theme.NexusEmerald
import com.raylan.nexusspace.free.ui.theme.NexusGold
import com.raylan.nexusspace.free.ui.theme.NexusLogoGlyph
import com.raylan.nexusspace.free.ui.theme.NexusSurfaceCard
import com.raylan.nexusspace.free.ui.theme.NexusSurfaceDark
import com.raylan.nexusspace.free.ui.theme.NexusTextPrimary
import com.raylan.nexusspace.free.ui.theme.NexusTextSecondary
import com.raylan.nexusspace.free.ui.theme.TurboLightningGlyph
import com.raylan.nexusspace.free.ui.theme.VipBannerButton
import com.raylan.nexusspace.free.ui.theme.VipCrownGlyph
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class DesktopShortcutItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val badge: String? = null,
    val isVip: Boolean = false,
    val appIcon: ImageBitmap? = null,
    val accent: Color = NexusCyan,
    val iconType: DesktopIconKind = DesktopIconKind.GAME,
    val onClick: () -> Unit
)

private enum class DesktopIconKind {
    GAME, GAME_SPACE, TURBO, SENSI, ICE_VIP, DISCORD_VIP, WALLPAPER
}

@Composable
fun VirtualPcDesktopScreen(
    currentSection: DesktopSection,
    onNavigateSection: (DesktopSection) -> Unit,
    onToggleHudOverlay: () -> Unit,
    onReturnToNormalPhone: () -> Unit,
    contentOverlay: @Composable () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val config by NexusRepository.config.collectAsStateWithLifecycle()
    val telemetry by TelemetryMonitor.telemetry.collectAsStateWithLifecycle()
    val shizukuStatus by ShizukuManager.status.collectAsStateWithLifecycle()
    val shizukuFeedback by ShizukuManager.lastFeedback.collectAsStateWithLifecycle()
    val installedApps by NexusRepository.installedApps.collectAsStateWithLifecycle()

    var startMenuOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var clockText by remember { mutableStateOf("00:00") }

    LaunchedEffect(Unit) {
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        while (true) {
            clockText = fmt.format(Date())
            delay(15_000L)
        }
    }

    val selectedWallpaper = remember(config.selectedWallpaperId) {
        NexusRepository.wallpapersCatalog.firstOrNull { it.id == config.selectedWallpaperId }
            ?: NexusRepository.wallpapersCatalog.first()
    }

    val desktopItems = remember(installedApps, config.selectedGamePackage) {
        val priorityGames = installedApps.filter { it.isPriorityGame }.take(3)
        val gameItems = priorityGames.map { game ->
            DesktopShortcutItem(
                id = "app_${game.packageName}",
                title = game.name,
                subtitle = if (game.isInstalled) "Instalado" else "Atalho Jogo",
                badge = if (config.selectedGamePackage == game.packageName) "ALVO" else null,
                appIcon = game.iconBitmap,
                accent = NexusCyan,
                iconType = DesktopIconKind.GAME,
                onClick = {
                    startMenuOpen = false
                    NexusRepository.launchAppOrGame(context, game.packageName, game.name)
                }
            )
        }

        gameItems + listOf(
            DesktopShortcutItem(
                id = "nexus_game_space",
                title = "Nexus Game Space",
                subtitle = "3 Colunas • 14 Grátis",
                accent = NexusCyan,
                iconType = DesktopIconKind.GAME_SPACE,
                onClick = {
                    startMenuOpen = false
                    onNavigateSection(DesktopSection.GAME_SPACE)
                }
            ),
            DesktopShortcutItem(
                id = "turbo_gratis",
                title = "Turbo Grátis",
                subtitle = "Shizuku Boost",
                badge = "GRÁTIS",
                accent = NexusEmerald,
                iconType = DesktopIconKind.TURBO,
                onClick = {
                    startMenuOpen = false
                    scope.launch {
                        ShizukuManager.applyTurboFree(context, config.selectedGamePackage)
                        NexusRepository.postToast("Turbo Grátis aplicado em ${config.selectedGameName}!")
                    }
                }
            ),
            DesktopShortcutItem(
                id = "painel_sensi",
                title = "Painel Sensi",
                subtitle = "Sensi & Crosshair",
                accent = NexusBlueAccent,
                iconType = DesktopIconKind.SENSI,
                onClick = {
                    startMenuOpen = false
                    onNavigateSection(DesktopSection.SETTINGS)
                }
            ),
            DesktopShortcutItem(
                id = "wallpapers",
                title = "Papéis de Parede",
                subtitle = "3 Grátis + 3 VIP",
                accent = NexusCyan,
                iconType = DesktopIconKind.WALLPAPER,
                onClick = {
                    startMenuOpen = false
                    onNavigateSection(DesktopSection.WALLPAPERS)
                }
            ),
            DesktopShortcutItem(
                id = "modo_gelo_vip",
                title = "Modo Gelo (VIP 🔒)",
                subtitle = "Resfriamento Profundo",
                badge = "VIP 🔒",
                isVip = true,
                accent = NexusGold,
                iconType = DesktopIconKind.ICE_VIP,
                onClick = {
                    startMenuOpen = false
                    NexusRepository.showVipDialog("Modo Gelo (Resfriamento Profundo)")
                }
            ),
            DesktopShortcutItem(
                id = "comprar_vip_discord",
                title = "Comprar Versão VIP (Discord)",
                subtitle = "120/144Hz & Liso",
                badge = "DISCORD",
                isVip = true,
                accent = NexusGold,
                iconType = DesktopIconKind.DISCORD_VIP,
                onClick = {
                    startMenuOpen = false
                    NexusRepository.showVipDialog("NEXUS SPACE VIP • Acesso Discord")
                }
            )
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Wallpaper Background
        Image(
            painter = painterResource(id = selectedWallpaper.drawableRes ?: R.drawable.img_wallpaper_cyber_nexus),
            contentDescription = "Papel de parede ${selectedWallpaper.name}",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0x99060911), Color(0x4D060911), Color(0xBF060911))
                    )
                )
        )

        // Main Desktop Column (Top Bar + Workspace + Bottom Taskbar)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // TOP SYSTEM BAR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xD90A0E18))
                    .border(0.5.dp, Color(0x3370B5FF))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Shizuku + Feedback status
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (shizukuStatus.isPermissionGranted) NexusEmerald.copy(alpha = 0.16f)
                                else NexusAmber.copy(alpha = 0.16f)
                            )
                            .border(
                                1.dp,
                                if (shizukuStatus.isPermissionGranted) NexusEmerald else NexusAmber,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable {
                                if (!shizukuStatus.isBinderAlive) {
                                    ShizukuManager.openShizukuApp(context)
                                } else {
                                    ShizukuManager.requestPermission()
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                            .testTag("top_shizuku_status"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(if (shizukuStatus.isPermissionGranted) NexusEmerald else NexusAmber)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = if (shizukuStatus.isPermissionGranted) "Shizuku UID ${shizukuStatus.uid}" else "Conectar Shizuku",
                            color = if (shizukuStatus.isPermissionGranted) NexusEmerald else NexusAmber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }

                    Text(
                        text = shizukuFeedback,
                        color = NexusTextSecondary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Live Telemetry Pill
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF121A2C))
                        .border(1.dp, NexusCyan.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TelemetryMiniBadge("FPS", "${telemetry.fps}", NexusEmerald)
                    TelemetryMiniBadge("CPU", "${telemetry.cpuPercent}%", NexusCyan)
                    TelemetryMiniBadge("RAM", "${telemetry.ramPercent}%", NexusBlueAccent)
                    TelemetryMiniBadge("TEMP", "${"%.1f".format(telemetry.temperatureC)}°C", NexusAmber)
                }

                Spacer(modifier = Modifier.width(8.dp))

                // VIP Banner + HUD + Return to Normal Phone
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    VipBannerButton(
                        text = "★ OBTER NEXUS SPACE VIP",
                        compact = true,
                        onClick = { NexusRepository.showVipDialog("NEXUS SPACE VIP") }
                    )

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (config.isHudRunning) NexusCrimson.copy(alpha = 0.22f) else NexusCyan.copy(alpha = 0.20f))
                            .border(1.dp, if (config.isHudRunning) NexusCrimson else NexusCyan, RoundedCornerShape(8.dp))
                            .clickable(onClick = onToggleHudOverlay)
                            .padding(horizontal = 9.dp, vertical = 6.dp)
                            .testTag("top_toggle_hud_button")
                    ) {
                        Text(
                            text = if (config.isHudRunning) "HUD ON" else "Abrir HUD",
                            color = if (config.isHudRunning) NexusCrimson else NexusCyan,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 10.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF1F273B))
                            .border(1.dp, Color(0x44FFFFFF), RoundedCornerShape(8.dp))
                            .clickable(onClick = onReturnToNormalPhone)
                            .padding(horizontal = 9.dp, vertical = 6.dp)
                            .testTag("return_normal_phone_button")
                    ) {
                        Text(
                            text = "Voltar para o Celular Normal",
                            color = NexusTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            // CENTER WORKSPACE
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (currentSection == DesktopSection.DESKTOP) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Desktop Icons Grid
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 112.dp),
                            modifier = Modifier
                                .weight(1.8f)
                                .fillMaxHeight(),
                            contentPadding = PaddingValues(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(desktopItems, key = { it.id }) { item ->
                                DesktopIconTile(item = item)
                            }
                        }

                        // Right Floating Desktop Telemetry & Quick Launch Widget
                        Column(
                            modifier = Modifier
                                .weight(0.95f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(18.dp))
                                .background(Color(0xCC0A0F1B))
                                .border(1.dp, NexusCyan.copy(alpha = 0.30f), RoundedCornerShape(18.dp))
                                .padding(14.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    NexusLogoGlyph(size = 24.dp)
                                    Column {
                                        Text(
                                            text = "NEXUS PC VIRTUAL",
                                            color = NexusTextPrimary,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = "Jogo foco: ${config.selectedGameName}",
                                            color = NexusCyan,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    DesktopStatBox("Refresh", "${config.refreshRateHz} Hz", NexusCyan, Modifier.weight(1f))
                                    DesktopStatBox("Sensi", "${"%.2f".format(config.sensiMultiplier)}x", NexusEmerald, Modifier.weight(1f))
                                    DesktopStatBox("Modo", config.gameMode.label, NexusBlueAccent, Modifier.weight(1f))
                                }

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0xFF101726))
                                        .padding(10.dp)
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(
                                            text = "TELEMETRIA EM TEMPO REAL",
                                            color = NexusCyan,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp
                                        )
                                        Text(
                                            text = "${telemetry.fps} FPS • CPU ${telemetry.cpuPercent}% • RAM ${telemetry.ramPercent}% (${telemetry.ramUsedMb}/${telemetry.ramTotalMb}MB) • ${"%.1f".format(telemetry.temperatureC)}°C",
                                            color = NexusTextPrimary,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { onNavigateSection(DesktopSection.GAME_SPACE) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = NexusCyan,
                                        contentColor = Color(0xFF00141A)
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(44.dp)
                                        .testTag("open_game_space_cta")
                                ) {
                                    Text(
                                        text = "ABRIR CENTRAL 3 COLUNAS",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 12.sp
                                    )
                                }

                                Button(
                                    onClick = onToggleHudOverlay,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF182238),
                                        contentColor = NexusTextPrimary
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(42.dp)
                                        .border(1.dp, NexusCyan.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                ) {
                                    Text(
                                        text = if (config.isHudRunning) "DESATIVAR HUD FLUTUANTE" else "ATIVAR HUD FLUTUANTE NO JOGO",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                } else {
                    contentOverlay()
                }

                // START MENU POPUP OVERLAY
                androidx.compose.animation.AnimatedVisibility(
                    visible = startMenuOpen,
                    enter = fadeIn() + slideInVertically { it / 3 },
                    exit = fadeOut() + slideOutVertically { it / 3 },
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 12.dp, bottom = 10.dp)
                ) {
                    StartMenuPanel(
                        searchQuery = searchQuery,
                        onSearchChange = { searchQuery = it },
                        installedApps = installedApps,
                        onLaunchApp = { app ->
                            startMenuOpen = false
                            NexusRepository.launchAppOrGame(context, app.packageName, app.name)
                        },
                        onOpenGameSpace = {
                            startMenuOpen = false
                            onNavigateSection(DesktopSection.GAME_SPACE)
                        },
                        onOpenVip = {
                            startMenuOpen = false
                            NexusRepository.showVipDialog("NEXUS SPACE VIP")
                        },
                        onReturnNormalPhone = {
                            startMenuOpen = false
                            onReturnToNormalPhone()
                        },
                        onClose = { startMenuOpen = false }
                    )
                }
            }

            // BOTTOM WINDOWS/STEAMOS TASKBAR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .background(Color(0xE6080C15))
                    .border(0.5.dp, Color(0x4470B5FF))
                    .padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Start Button
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (startMenuOpen) NexusCyan else Color(0xFF162036)
                            )
                            .border(1.dp, NexusCyan.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                            .clickable { startMenuOpen = !startMenuOpen }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                            .testTag("taskbar_start_button"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        NexusLogoGlyph(
                            size = 18.dp,
                            tint = if (startMenuOpen) Color(0xFF00141A) else NexusCyan
                        )
                        Text(
                            text = "INICIAR",
                            color = if (startMenuOpen) Color(0xFF00141A) else NexusTextPrimary,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 11.sp
                        )
                    }

                    TaskbarPillButton(
                        label = "Desktop",
                        active = currentSection == DesktopSection.DESKTOP,
                        onClick = {
                            startMenuOpen = false
                            onNavigateSection(DesktopSection.DESKTOP)
                        }
                    )
                    TaskbarPillButton(
                        label = "Game Space",
                        active = currentSection == DesktopSection.GAME_SPACE || currentSection == DesktopSection.SETTINGS,
                        onClick = {
                            startMenuOpen = false
                            onNavigateSection(DesktopSection.GAME_SPACE)
                        }
                    )
                    TaskbarPillButton(
                        label = "Wallpapers",
                        active = currentSection == DesktopSection.WALLPAPERS,
                        onClick = {
                            startMenuOpen = false
                            onNavigateSection(DesktopSection.WALLPAPERS)
                        }
                    )
                    TaskbarPillButton(
                        label = "Turbo Grátis",
                        active = false,
                        accent = NexusEmerald,
                        onClick = {
                            scope.launch {
                                ShizukuManager.applyTurboFree(context, config.selectedGamePackage)
                            }
                        }
                    )
                }

                // Right System Tray: Credits + VIP + Clock
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = OFFICIAL_CREDITS,
                        color = NexusTextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1
                    )
                    VipBannerButton(
                        text = "★ COMPRAR VIP",
                        compact = true,
                        onClick = { NexusRepository.showVipDialog("NEXUS SPACE VIP") }
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF131B2E))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = clockText,
                            color = NexusTextPrimary,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DesktopIconTile(item: DesktopShortcutItem) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xB80B101D))
            .border(
                1.dp,
                if (item.isVip) NexusGold.copy(alpha = 0.55f) else item.accent.copy(alpha = 0.30f),
                RoundedCornerShape(14.dp)
            )
            .clickable(onClick = item.onClick)
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(item.accent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                when {
                    item.appIcon != null -> {
                        Image(
                            bitmap = item.appIcon,
                            contentDescription = item.title,
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(9.dp))
                        )
                    }
                    item.iconType == DesktopIconKind.GAME -> GamepadGlyph(size = 28.dp, tint = item.accent)
                    item.iconType == DesktopIconKind.GAME_SPACE -> NexusLogoGlyph(size = 28.dp, tint = item.accent)
                    item.iconType == DesktopIconKind.TURBO -> TurboLightningGlyph(size = 28.dp, tint = NexusEmerald)
                    item.iconType == DesktopIconKind.SENSI -> CrosshairCanvas(style = com.raylan.nexusspace.free.data.CrosshairStyle.CROSS, size = 28.dp, color = item.accent)
                    item.iconType == DesktopIconKind.ICE_VIP -> IceCrystalGlyph(size = 28.dp, tint = Color(0xFF7CE8FF))
                    item.iconType == DesktopIconKind.DISCORD_VIP -> VipCrownGlyph(size = 26.dp, tint = NexusGold)
                    item.iconType == DesktopIconKind.WALLPAPER -> Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = item.title,
                        tint = item.accent,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            if (item.badge != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (item.isVip) NexusGold else NexusEmerald)
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = item.badge,
                        color = Color(0xFF0A0E17),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 8.sp
                    )
                }
            }
        }

        Text(
            text = item.title,
            color = if (item.isVip) NexusGold else NexusTextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = item.subtitle,
            color = NexusTextSecondary,
            fontSize = 9.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun StartMenuPanel(
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    installedApps: List<InstalledAppInfo>,
    onLaunchApp: (InstalledAppInfo) -> Unit,
    onOpenGameSpace: () -> Unit,
    onOpenVip: () -> Unit,
    onReturnNormalPhone: () -> Unit,
    onClose: () -> Unit
) {
    val filteredApps = remember(installedApps, searchQuery) {
        if (searchQuery.isBlank()) installedApps
        else installedApps.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
                it.packageName.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .width(420.dp)
            .height(330.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xF50B101D))
            .border(1.5.dp, NexusCyan.copy(alpha = 0.55f), RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                NexusLogoGlyph(size = 20.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "MENU INICIAR • APPS & JOGOS",
                    color = NexusTextPrimary,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp
                )
            }
            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Fechar Menu Iniciar", tint = NexusTextSecondary)
            }
        }

        VipBannerButton(
            text = "★ OBTER NEXUS SPACE VIP",
            onClick = onOpenVip,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            placeholder = { Text("Buscar jogos ou aplicativos instalados...", fontSize = 12.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = NexusCyan) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NexusCyan,
                unfocusedBorderColor = Color(0x33FFFFFF),
                focusedTextColor = NexusTextPrimary,
                unfocusedTextColor = NexusTextPrimary
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(filteredApps, key = { it.packageName }) { app ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(NexusSurfaceCard)
                        .clickable { onLaunchApp(app) }
                        .padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        if (app.iconBitmap != null) {
                            Image(
                                bitmap = app.iconBitmap,
                                contentDescription = app.name,
                                modifier = Modifier
                                    .size(26.dp)
                                    .clip(RoundedCornerShape(6.dp))
                            )
                        } else {
                            GamepadGlyph(size = 24.dp)
                        }
                        Column {
                            Text(
                                text = app.name,
                                color = NexusTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = app.packageName,
                                color = NexusTextSecondary,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Text(
                        text = if (app.isInstalled) "ABRIR" else "N/INST",
                        color = if (app.isInstalled) NexusEmerald else NexusTextSecondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onOpenGameSpace,
                colors = ButtonDefaults.buttonColors(containerColor = NexusSurfaceCard, contentColor = NexusCyan),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f).height(38.dp)
            ) {
                Text("Game Space", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = onReturnNormalPhone,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF28151A), contentColor = NexusCrimson),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f).height(38.dp)
            ) {
                Text("Celular Normal", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun TaskbarPillButton(
    label: String,
    active: Boolean,
    accent: Color = NexusCyan,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(9.dp))
            .background(if (active) accent.copy(alpha = 0.22f) else Color(0xFF131B2E))
            .border(1.dp, if (active) accent else Color(0x22FFFFFF), RoundedCornerShape(9.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 7.dp)
    ) {
        Text(
            text = label,
            color = if (active) accent else NexusTextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun TelemetryMiniBadge(label: String, value: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, color = NexusTextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, color = color, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp)
    }
}

@Composable
private fun DesktopStatBox(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF101726))
            .padding(8.dp)
    ) {
        Text(label, color = NexusTextSecondary, fontSize = 9.sp)
        Text(value, color = color, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
