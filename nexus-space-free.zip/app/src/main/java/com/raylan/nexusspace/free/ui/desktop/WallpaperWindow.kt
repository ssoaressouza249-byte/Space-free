package com.raylan.nexusspace.free.ui.desktop

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.raylan.nexusspace.free.data.NexusRepository
import com.raylan.nexusspace.free.data.OFFICIAL_CREDITS
import com.raylan.nexusspace.free.data.WallpaperOption
import com.raylan.nexusspace.free.ui.theme.NexusCyan
import com.raylan.nexusspace.free.ui.theme.NexusEmerald
import com.raylan.nexusspace.free.ui.theme.NexusGold
import com.raylan.nexusspace.free.ui.theme.NexusSurfaceCard
import com.raylan.nexusspace.free.ui.theme.NexusSurfaceDark
import com.raylan.nexusspace.free.ui.theme.NexusTextPrimary
import com.raylan.nexusspace.free.ui.theme.NexusTextSecondary

@Composable
fun WallpaperWindow(
    onBackToDesktop: () -> Unit
) {
    val config by NexusRepository.config.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xEB070B14))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Window Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(NexusSurfaceDark)
                .border(1.dp, NexusCyan.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onBackToDesktop,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(NexusSurfaceCard)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Voltar ao Desktop",
                        tint = NexusCyan
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "PAPÉIS DE PAREDE DO PC VIRTUAL",
                        color = NexusTextPrimary,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "3 Papéis de Parede Grátis liberados + 3 Exclusivos VIP",
                        color = NexusTextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            Button(
                onClick = { NexusRepository.showVipDialog("Importar Papel de Parede da Galeria") },
                colors = ButtonDefaults.buttonColors(
                    containerColor = NexusGold.copy(alpha = 0.18f),
                    contentColor = NexusGold
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .height(40.dp)
                    .border(1.dp, NexusGold.copy(alpha = 0.65f), RoundedCornerShape(10.dp))
                    .testTag("import_wallpaper_vip_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Importar da Galeria (VIP 🔒)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(NexusRepository.wallpapersCatalog, key = { it.id }) { wp ->
                WallpaperCard(
                    wallpaper = wp,
                    isSelected = config.selectedWallpaperId == wp.id && !wp.isVip,
                    onClick = {
                        if (wp.isVip) {
                            NexusRepository.showVipDialog("Wallpaper Exclusivo: ${wp.name}")
                        } else {
                            NexusRepository.updateConfig { it.copy(selectedWallpaperId = wp.id) }
                            NexusRepository.postToast("Papel de parede alterado para ${wp.name}")
                        }
                    }
                )
            }
        }

        Text(
            text = OFFICIAL_CREDITS,
            color = NexusTextSecondary,
            fontSize = 11.sp,
            modifier = Modifier.align(Alignment.End)
        )
    }
}

@Composable
private fun WallpaperCard(
    wallpaper: WallpaperOption,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val borderColor = when {
        wallpaper.isVip -> NexusGold.copy(alpha = 0.65f)
        isSelected -> NexusEmerald
        else -> Color(0x33FFFFFF)
    }

    Box(
        modifier = Modifier
            .height(145.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(NexusSurfaceCard)
            .border(if (isSelected) 2.dp else 1.dp, borderColor, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
    ) {
        if (wallpaper.drawableRes != null) {
            Image(
                painter = painterResource(id = wallpaper.drawableRes),
                contentDescription = wallpaper.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Custom stylized VIP artwork preview
            val primary = Color(wallpaper.primaryHex)
            val accent = Color(wallpaper.accentHex)
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawRect(
                    brush = Brush.linearGradient(
                        listOf(primary, Color(0xFF070910), accent.copy(alpha = 0.35f))
                    )
                )
                drawCircle(
                    color = accent.copy(alpha = 0.30f),
                    radius = size.minDimension * 0.45f,
                    center = Offset(size.width * 0.72f, size.height * 0.35f)
                )
                drawLine(
                    color = accent.copy(alpha = 0.65f),
                    start = Offset(0f, size.height * 0.78f),
                    end = Offset(size.width, size.height * 0.42f),
                    strokeWidth = 4f
                )
            }
        }

        // Bottom overlay label
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Color(0xCC060911))
                .padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = wallpaper.name,
                color = if (wallpaper.isVip) NexusGold else NexusTextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
            when {
                wallpaper.isVip -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "VIP",
                            tint = NexusGold,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("VIP 🔒", color = NexusGold, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp)
                    }
                }
                isSelected -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Ativo",
                            tint = NexusEmerald,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("ATIVO", color = NexusEmerald, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    }
                }
                else -> {
                    Text("GRÁTIS", color = NexusCyan, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                }
            }
        }
    }
}
