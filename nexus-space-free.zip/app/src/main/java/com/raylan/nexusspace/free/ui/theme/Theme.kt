package com.raylan.nexusspace.free.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NexusDarkColorScheme = darkColorScheme(
    primary = NexusCyan,
    onPrimary = Color(0xFF00141A),
    primaryContainer = Color(0xFF003642),
    onPrimaryContainer = NexusCyan,
    secondary = NexusGold,
    onSecondary = Color(0xFF1F1600),
    secondaryContainer = Color(0xFF3D2E00),
    onSecondaryContainer = NexusGold,
    tertiary = NexusEmerald,
    onTertiary = Color(0xFF00210E),
    background = NexusObsidianBg,
    onBackground = NexusTextPrimary,
    surface = NexusSurfaceDark,
    onSurface = NexusTextPrimary,
    surfaceVariant = NexusSurfaceCard,
    onSurfaceVariant = NexusTextSecondary,
    outline = NexusGlassBorder,
    error = NexusCrimson,
    onError = Color.White
)

@Composable
fun NexusSpaceTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NexusDarkColorScheme,
        typography = NexusTypography,
        content = content
    )
}
