package com.raylan.nexusspace.free.data

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.Settings
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.raylan.nexusspace.free.R
import com.raylan.nexusspace.free.telemetry.TelemetryMonitor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

object NexusRepository {
    private const val PREFS_NAME = "nexus_space_prefs"
    private const val KEY_GAME_PKG = "selected_game_pkg"
    private const val KEY_GAME_NAME = "selected_game_name"
    private const val KEY_REFRESH_HZ = "refresh_hz"
    private const val KEY_ANIM_SPEED = "anim_speed"
    private const val KEY_SENSI = "sensi_mult"
    private const val KEY_QUICK_TOUCH = "quick_touch"
    private const val KEY_CROSSHAIR = "crosshair_style"
    private const val KEY_GAME_MODE = "game_mode"
    private const val KEY_WALLPAPER = "wallpaper_id"

    private val priorityGamePackages = mapOf(
        "com.dts.freefireth" to "Free Fire",
        "com.dts.freefiremax" to "Free Fire MAX",
        "com.roblox.client" to "Roblox",
        "com.tencent.ig" to "PUBG Mobile",
        "com.activision.callofduty.shooter" to "Call of Duty",
        "com.mobile.legends" to "Mobile Legends",
        "com.supercell.brawlstars" to "Brawl Stars"
    )

    val wallpapersCatalog: List<WallpaperOption> = listOf(
        WallpaperOption(
            id = "wp_cyber_nexus",
            name = "Cyber Nexus",
            drawableRes = R.drawable.img_wallpaper_cyber_nexus,
            isVip = false,
            primaryHex = 0xFF071326,
            accentHex = 0xFF00E5FF
        ),
        WallpaperOption(
            id = "wp_obsidian_forge",
            name = "Obsidian Forge",
            drawableRes = R.drawable.img_wallpaper_obsidian_forge,
            isVip = false,
            primaryHex = 0xFF0D101B,
            accentHex = 0xFF536DFE
        ),
        WallpaperOption(
            id = "wp_amber_wave",
            name = "Fluxo Quântico",
            drawableRes = R.drawable.img_wallpaper_amber_wave,
            isVip = false,
            primaryHex = 0xFF0B1117,
            accentHex = 0xFFFFB300
        ),
        WallpaperOption(
            id = "wp_vip_gold",
            name = "Imperial Gold",
            drawableRes = null,
            isVip = true,
            primaryHex = 0xFF1F1604,
            accentHex = 0xFFFFD700
        ),
        WallpaperOption(
            id = "wp_vip_nebula",
            name = "Plasma Nebula",
            drawableRes = null,
            isVip = true,
            primaryHex = 0xFF1D0726,
            accentHex = 0xFFFF4081
        ),
        WallpaperOption(
            id = "wp_vip_dragon",
            name = "Stealth Dragon",
            drawableRes = null,
            isVip = true,
            primaryHex = 0xFF051C16,
            accentHex = 0xFF00E676
        )
    )

    private val _config = MutableStateFlow(NexusConfigState())
    val config: StateFlow<NexusConfigState> = _config.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _vipDialogFeature = MutableStateFlow<String?>(null)
    val vipDialogFeature: StateFlow<String?> = _vipDialogFeature.asStateFlow()

    private val _statusToast = MutableStateFlow<String?>(null)
    val statusToast: StateFlow<String?> = _statusToast.asStateFlow()

    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs == null) {
            prefs = runCatching {
                context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            }.getOrNull()
        }
        loadPreferences(context)
    }

    private fun loadPreferences(context: Context) {
        val p = prefs
        val animName = p?.getString(KEY_ANIM_SPEED, AnimationSpeed.FAST.name) ?: AnimationSpeed.FAST.name
        val crossName = p?.getString(KEY_CROSSHAIR, CrosshairStyle.NONE.name) ?: CrosshairStyle.NONE.name
        val modeName = p?.getString(KEY_GAME_MODE, GameModeOption.BALANCED.name) ?: GameModeOption.BALANCED.name

        _config.value = _config.value.copy(
            selectedGamePackage = p?.getString(KEY_GAME_PKG, "com.dts.freefireth") ?: "com.dts.freefireth",
            selectedGameName = p?.getString(KEY_GAME_NAME, "Free Fire") ?: "Free Fire",
            refreshRateHz = p?.getInt(KEY_REFRESH_HZ, 60) ?: 60,
            animationSpeed = runCatching { AnimationSpeed.valueOf(animName) }.getOrDefault(AnimationSpeed.FAST),
            sensiMultiplier = p?.getFloat(KEY_SENSI, 1.00f) ?: 1.00f,
            quickTouchEnabled = p?.getBoolean(KEY_QUICK_TOUCH, false) ?: false,
            crosshairStyle = runCatching { CrosshairStyle.valueOf(crossName) }.getOrDefault(CrosshairStyle.NONE),
            gameMode = runCatching { GameModeOption.valueOf(modeName) }.getOrDefault(GameModeOption.BALANCED),
            selectedWallpaperId = p?.getString(KEY_WALLPAPER, "wp_cyber_nexus") ?: "wp_cyber_nexus",
            brightnessPercent = TelemetryMonitor.getCurrentBrightnessPercent(context),
            volumePercent = TelemetryMonitor.getCurrentVolumePercent(context)
        )
    }

    fun updateConfig(transform: (NexusConfigState) -> NexusConfigState) {
        val updated = transform(_config.value)
        _config.value = updated
        runCatching {
            prefs?.edit()?.apply {
                putString(KEY_GAME_PKG, updated.selectedGamePackage)
                putString(KEY_GAME_NAME, updated.selectedGameName)
                putInt(KEY_REFRESH_HZ, updated.refreshRateHz)
                putString(KEY_ANIM_SPEED, updated.animationSpeed.name)
                putFloat(KEY_SENSI, updated.sensiMultiplier)
                putBoolean(KEY_QUICK_TOUCH, updated.quickTouchEnabled)
                putString(KEY_CROSSHAIR, updated.crosshairStyle.name)
                putString(KEY_GAME_MODE, updated.gameMode.name)
                putString(KEY_WALLPAPER, updated.selectedWallpaperId)
                apply()
            }
        }
    }

    fun setHudRunning(running: Boolean) {
        _config.value = _config.value.copy(isHudRunning = running)
    }

    fun showVipDialog(featureName: String) {
        _vipDialogFeature.value = featureName
    }

    fun dismissVipDialog() {
        _vipDialogFeature.value = null
    }

    fun postToast(message: String) {
        _statusToast.value = message
    }

    fun clearToast() {
        _statusToast.value = null
    }

    suspend fun loadInstalledApps(context: Context) = withContext(Dispatchers.IO) {
        val list = mutableListOf<InstalledAppInfo>()
        val pm = context.packageManager

        val installedMap = mutableMapOf<String, ApplicationInfo>()
        runCatching {
            val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            apps.forEach { info ->
                if (info.packageName != context.packageName && pm.getLaunchIntentForPackage(info.packageName) != null) {
                    installedMap[info.packageName] = info
                }
            }
        }

        // Always feature Free Fire, Free Fire MAX, Roblox at the front of the desktop
        listOf("com.dts.freefireth", "com.dts.freefiremax", "com.roblox.client").forEach { pkg ->
            val appInfo = installedMap[pkg]
            val label = if (appInfo != null) {
                runCatching { appInfo.loadLabel(pm).toString() }.getOrDefault(priorityGamePackages[pkg] ?: pkg)
            } else {
                priorityGamePackages[pkg] ?: pkg
            }
            val icon = appInfo?.let { loadAppIconBitmap(pm, it) }
            list.add(
                InstalledAppInfo(
                    name = label,
                    packageName = pkg,
                    isPriorityGame = true,
                    isInstalled = appInfo != null,
                    iconBitmap = icon
                )
            )
        }

        installedMap.values
            .filter { it.packageName !in setOf("com.dts.freefireth", "com.dts.freefiremax", "com.roblox.client") }
            .sortedBy { runCatching { it.loadLabel(pm).toString().lowercase() }.getOrDefault(it.packageName) }
            .take(60)
            .forEach { appInfo ->
                val isPriority = priorityGamePackages.containsKey(appInfo.packageName) ||
                    (appInfo.category == ApplicationInfo.CATEGORY_GAME)
                val label = runCatching { appInfo.loadLabel(pm).toString() }.getOrDefault(appInfo.packageName)
                val icon = loadAppIconBitmap(pm, appInfo)
                list.add(
                    InstalledAppInfo(
                        name = label,
                        packageName = appInfo.packageName,
                        isPriorityGame = isPriority,
                        isInstalled = true,
                        iconBitmap = icon
                    )
                )
            }

        _installedApps.value = list
    }

    private fun loadAppIconBitmap(pm: PackageManager, info: ApplicationInfo): ImageBitmap? {
        return runCatching {
            val drawable: Drawable = info.loadIcon(pm)
            val width = 72
            val height = 72
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, width, height)
            drawable.draw(canvas)
            bitmap.asImageBitmap()
        }.getOrNull()
    }

    fun launchAppOrGame(context: Context, packageName: String, appName: String) {
        val launched = runCatching {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                true
            } else {
                false
            }
        }.getOrDefault(false)

        if (launched) {
            updateConfig {
                it.copy(
                    selectedGamePackage = packageName,
                    selectedGameName = appName
                )
            }
            postToast("Iniciando $appName...")
        } else {
            postToast("$appName não está instalado neste dispositivo.")
        }
    }

    fun openDiscordVip(context: Context) {
        runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(DISCORD_VIP_URL)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }.onFailure {
            postToast("Abra no navegador: $DISCORD_VIP_URL")
        }
    }

    fun openOverlayPermissionSettings(context: Context) {
        runCatching {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }

    fun openWriteSettingsScreen(context: Context) {
        runCatching {
            val intent = Intent(
                Settings.ACTION_MANAGE_WRITE_SETTINGS,
                Uri.parse("package:${context.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}
