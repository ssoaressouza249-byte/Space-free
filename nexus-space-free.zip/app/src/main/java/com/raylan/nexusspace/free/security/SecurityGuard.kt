package com.raylan.nexusspace.free.security

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.nexusspace.free.data.OFFICIAL_CREDITS

data class IntegrityResult(
    val isValid: Boolean,
    val detectedPackage: String,
    val detectedLabel: String,
    val reason: String? = null
)

object SecurityGuard {
    private const val EXPECTED_PACKAGE = "com.raylan.nexusspace.free"
    private const val EXPECTED_LABEL = "NEXUS SPACE FREE"

    fun verifyIntegrity(context: Context): IntegrityResult {
        val pkgResult = runCatching { context.packageName }.getOrDefault("")
        val labelResult = runCatching {
            val pm = context.packageManager
            val appInfo = context.applicationInfo
            appInfo.loadLabel(pm).toString()
        }.getOrDefault("")

        val packageMatches = pkgResult == EXPECTED_PACKAGE
        val labelMatches = labelResult == EXPECTED_LABEL

        val reason = when {
            !packageMatches && !labelMatches ->
                "Pacote ($pkgResult) e nome ($labelResult) foram adulterados."
            !packageMatches ->
                "Pacote modificado detectado: $pkgResult"
            !labelMatches ->
                "Rótulo do aplicativo modificado detectado: $labelResult"
            else -> null
        }

        return IntegrityResult(
            isValid = packageMatches && labelMatches,
            detectedPackage = pkgResult,
            detectedLabel = labelResult,
            reason = reason
        )
    }

    fun triggerUninstall(context: Context) {
        runCatching {
            val intent = Intent(Intent.ACTION_DELETE).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}

@Composable
fun TamperLockScreen(result: IntegrityResult) {
    val context = LocalContext.current

    // Fixed, irremovable lock screen
    BackHandler(enabled = true) {}

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF6B0014), Color(0xFF280006), Color(0xFF0E0002))
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 560.dp)
                .background(Color(0xCC1E0308), RoundedCornerShape(20.dp))
                .border(2.dp, Color(0xFFFF3D57), RoundedCornerShape(20.dp))
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Alerta de violação de integridade",
                tint = Color(0xFFFF5252),
                modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "MODIFICAÇÃO NÃO AUTORIZADA DETECTADA",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Este aplicativo foi alterado fora da distribuição oficial. A execução foi bloqueada permanentemente por segurança.",
                color = Color(0xFFFFCDD2),
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = result.reason ?: "Assinatura de pacote inválida.",
                color = Color(0xFFFF8A80),
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = { SecurityGuard.triggerUninstall(context) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFD50000),
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .height(52.dp)
                    .testTag("uninstall_tampered_app_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Desinstalar aplicativo",
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.size(8.dp))
                Text(
                    text = "DESINSTALAR AGORA",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = OFFICIAL_CREDITS,
                color = Color(0xAAFFCDD2),
                fontSize = 11.sp
            )
        }
    }
}
